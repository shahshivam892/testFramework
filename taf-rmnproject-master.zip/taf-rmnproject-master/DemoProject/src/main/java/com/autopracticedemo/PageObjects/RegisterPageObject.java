package com.autopracticedemo.PageObjects;

import com.autopracticedemo.ElementProviders.RegisterPageElementProvider;
import com.taf.core.TestContext;
import com.taf.core.TestPage;
import com.taf.impl.selenium.SeleniumTestContext;

/**
 * The Class RegisterPageObject.
 */
public class RegisterPageObject extends TestPage {

    /** The selenium test context. */
    private final SeleniumTestContext seleniumTestContext;

    /** The sign up page element provider. */
    private RegisterPageElementProvider registerPageElementProvider;

    /**
     * Instantiates a new sign up page.
     *
     * @param context
     *            the context
     */
    public RegisterPageObject(final TestContext context){
        super(context);
        seleniumTestContext = (SeleniumTestContext) context;
    }
    
    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestPage#intializeElementProvider()
     */
    @Override
    public void initializeElementProvider(){
        registerPageElementProvider = new RegisterPageElementProvider(seleniumTestContext);
    }
    
    
          
    public void clickId_gender1(){
		     seleniumTestContext.clickButton(registerPageElementProvider.getId_gender1());
		}
		
         
    public void enterCustomer_firstname(final String text){
		     seleniumTestContext.enterTextIn(registerPageElementProvider.getCustomer_firstname(),text);
		}
		
         
    public void clickCustomer_firstname(){
		     seleniumTestContext.clickButton(registerPageElementProvider.getCustomer_firstname());
		}
		
         
    public void clickCustomer_lastname(){
		     seleniumTestContext.clickButton(registerPageElementProvider.getCustomer_lastname());
		}
		
         
    public void enterCustomer_lastname(final String text){
		     seleniumTestContext.enterTextIn(registerPageElementProvider.getCustomer_lastname(),text);
		}
		
         
    public void clickPasswd(){
		     seleniumTestContext.clickButton(registerPageElementProvider.getPasswd());
		}
		
         
    public void enterPasswd(final String text){
		     seleniumTestContext.enterTextIn(registerPageElementProvider.getPasswd(),text);
		}
		
         
    public void clickCompany(){
		     seleniumTestContext.clickButton(registerPageElementProvider.getCompany());
		}
		
         
    public void enterCompany(final String text){
		     seleniumTestContext.enterTextIn(registerPageElementProvider.getCompany(),text);
		}
		
         
    public void clickAddress1(){
		     seleniumTestContext.clickButton(registerPageElementProvider.getAddress1());
		}
		
         
    public void enterAddress1(final String text){
		     seleniumTestContext.enterTextIn(registerPageElementProvider.getAddress1(),text);
		}
		
         
    public void clickCity(){
		     seleniumTestContext.clickButton(registerPageElementProvider.getCity());
		}
		
         
    public void enterCity(final String text){
		     seleniumTestContext.enterTextIn(registerPageElementProvider.getCity(),text);
		}
		
         
    public void clickId_state(){
		     seleniumTestContext.clickButton(registerPageElementProvider.getId_state());
		}
		
         
    public void selectId_state(final String text){
		     seleniumTestContext.selectElementByVisibleText(registerPageElementProvider.getId_state(),text);
		}
		
         
    public void clickPostcode(){
		     seleniumTestContext.clickButton(registerPageElementProvider.getPostcode());
		}
		
         
    public void enterPostcode(final String text){
		     seleniumTestContext.enterTextIn(registerPageElementProvider.getPostcode(),text);
		}
		
         
    public void clickPhone_mobile(){
		     seleniumTestContext.clickButton(registerPageElementProvider.getPhone_mobile());
		}
		
         
    public void enterPhone_mobile(final String text){
		     seleniumTestContext.enterTextIn(registerPageElementProvider.getPhone_mobile(),text);
		}
		
         
    public void clickAlias(){
		     seleniumTestContext.clickButton(registerPageElementProvider.getAlias());
		}
		
         
    public void enterAlias(final String text){
		     seleniumTestContext.enterTextIn(registerPageElementProvider.getAlias(),text);
		}
		
         
    public void clickSubmitAccountgtspan(){
		     seleniumTestContext.clickButton(registerPageElementProvider.getSubmitAccountgtspan());
		}
		
         
    public String assertTextPinfoaccount(){
		    return seleniumTestContext.getText(registerPageElementProvider.getPinfoaccount());
		}
		
        
        
    public void RegisterFunc(String customer_firstname,String customer_lastname,String passwd,String company,String address1,String city,String id_state,String postcode,String phone_mobile,String alias){
		    		    clickId_gender1();
		    		    enterCustomer_firstname(customer_firstname);
		    		    clickCustomer_firstname();
		    		    clickCustomer_lastname();
		    		    enterCustomer_lastname(customer_lastname);
		    		    clickPasswd();
		    		    enterPasswd(passwd);
		    		    clickCompany();
		    		    enterCompany(company);
		    		    clickAddress1();
		    		    enterAddress1(address1);
		    		    clickCity();
		    		    enterCity(city);
		    		    clickId_state();
		    		    selectId_state(id_state);
		    		    clickPostcode();
		    		    enterPostcode(postcode);
		    		    clickPhone_mobile();
		    		    enterPhone_mobile(phone_mobile);
		    		    clickAlias();
		    		    enterAlias(alias);
		    		    clickSubmitAccountgtspan();
		    		}
		
      }
    