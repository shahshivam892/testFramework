package com.autopracticedemo.ElementProviders;

import org.openqa.selenium.By;

import com.taf.core.PageElementProvider;
import com.taf.core.TestContext;
import com.taf.impl.selenium.SeleniumElementProvider;
import com.taf.impl.selenium.SeleniumTestContext;

/**
 * The Class HomePageElementProvider.
 */
public class HomePageElementProvider extends PageElementProvider {

    /** The selenium test context. */
    protected SeleniumTestContext seleniumTestContext;

    /** The selenium element provider. */
    protected SeleniumElementProvider seleniumElementProvider;

    /**
     * Instantiates a new base element provider.
     *
     * @param context
     *            the context
     */
    public HomePageElementProvider(final TestContext context) {
        super(context);
        seleniumTestContext = (SeleniumTestContext) context;
        seleniumElementProvider = new SeleniumElementProvider(seleniumTestContext);
    }

					
		public Object getSignin(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.linkText("Sign in"));
		        return seleniumElementProvider.getElementByLinkText("Sign in");
	    	}
	    	
    			
		public Object getEmail_create(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("email_create"));
		        return seleniumElementProvider.getElementByID("email_create");
	    	}
	    	
    			
		public Object getSubmitCreategtspan(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.cssSelector("#SubmitCreate"));
		        return seleniumElementProvider.getElementByCSSSelector("#SubmitCreate");
	    	}
	    	
    					
		public Object getContactus(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.linkText("Contact us"));
		        return seleniumElementProvider.getElementByLinkText("Contact us");
	    	}
	    	
    	}