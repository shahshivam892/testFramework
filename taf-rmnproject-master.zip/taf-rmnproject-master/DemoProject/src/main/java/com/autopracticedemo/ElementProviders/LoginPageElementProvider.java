package com.autopracticedemo.ElementProviders;

import org.openqa.selenium.By;

import com.taf.core.PageElementProvider;
import com.taf.core.TestContext;
import com.taf.impl.selenium.SeleniumElementProvider;
import com.taf.impl.selenium.SeleniumTestContext;

/**
 * The Class LoginPageElementProvider.
 */
public class LoginPageElementProvider extends PageElementProvider {

    /** The selenium test context. */
    protected SeleniumTestContext seleniumTestContext;

    /** The selenium element provider. */
    protected SeleniumElementProvider seleniumElementProvider;

    /**
     * Instantiates a new base element provider.
     *
     * @param context
     *            the context
     */
    public LoginPageElementProvider(final TestContext context) {
        super(context);
        seleniumTestContext = (SeleniumTestContext) context;
        seleniumElementProvider = new SeleniumElementProvider(seleniumTestContext);
    }

			
		public Object getEmail(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("email"));
		        return seleniumElementProvider.getElementByID("email");
	    	}
	    	
    			
		public Object getPasswd(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("passwd"));
		        return seleniumElementProvider.getElementByID("passwd");
	    	}
	    	
    			
		public Object getSubmitLogingtspan(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.cssSelector("#SubmitLogin"));
		        return seleniumElementProvider.getElementByCSSSelector("#SubmitLogin");
	    	}
	    	
    			
		public Object getPinfoaccount(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.cssSelector("p.info-account"));
		        return seleniumElementProvider.getElementByCSSSelector("p.info-account");
	    	}
	    	
    	}