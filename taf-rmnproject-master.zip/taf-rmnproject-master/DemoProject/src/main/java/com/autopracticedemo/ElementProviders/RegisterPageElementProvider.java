package com.autopracticedemo.ElementProviders;

import org.openqa.selenium.By;

import com.taf.core.PageElementProvider;
import com.taf.core.TestContext;
import com.taf.impl.selenium.SeleniumElementProvider;
import com.taf.impl.selenium.SeleniumTestContext;

/**
 * The Class RegisterPageElementProvider.
 */
public class RegisterPageElementProvider extends PageElementProvider {

    /** The selenium test context. */
    protected SeleniumTestContext seleniumTestContext;

    /** The selenium element provider. */
    protected SeleniumElementProvider seleniumElementProvider;

    /**
     * Instantiates a new base element provider.
     *
     * @param context
     *            the context
     */
    public RegisterPageElementProvider(final TestContext context) {
        super(context);
        seleniumTestContext = (SeleniumTestContext) context;
        seleniumElementProvider = new SeleniumElementProvider(seleniumTestContext);
    }

			
		public Object getId_gender1(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("id_gender1"));
		        return seleniumElementProvider.getElementByID("id_gender1");
	    	}
	    	
    			
		public Object getCustomer_firstname(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("customer_firstname"));
		        return seleniumElementProvider.getElementByID("customer_firstname");
	    	}
	    	
    			
		public Object getCustomer_lastname(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("customer_lastname"));
		        return seleniumElementProvider.getElementByID("customer_lastname");
	    	}
	    	
    			
		public Object getPasswd(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("passwd"));
		        return seleniumElementProvider.getElementByID("passwd");
	    	}
	    	
    			
		public Object getCompany(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("company"));
		        return seleniumElementProvider.getElementByID("company");
	    	}
	    	
    			
		public Object getAddress1(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("address1"));
		        return seleniumElementProvider.getElementByID("address1");
	    	}
	    	
    			
		public Object getCity(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("city"));
		        return seleniumElementProvider.getElementByID("city");
	    	}
	    	
    			
		public Object getId_state(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("id_state"));
		        return seleniumElementProvider.getElementByID("id_state");
	    	}
	    	
    			
		public Object getPostcode(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("postcode"));
		        return seleniumElementProvider.getElementByID("postcode");
	    	}
	    	
    			
		public Object getPhone_mobile(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("phone_mobile"));
		        return seleniumElementProvider.getElementByID("phone_mobile");
	    	}
	    	
    			
		public Object getAlias(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("alias"));
		        return seleniumElementProvider.getElementByID("alias");
	    	}
	    	
    			
		public Object getSubmitAccountgtspan(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.cssSelector("#submitAccount"));
		        return seleniumElementProvider.getElementByCSSSelector("#submitAccount");
	    	}
	    	
    			
		public Object getPinfoaccount(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.cssSelector("p.info-account"));
		        return seleniumElementProvider.getElementByCSSSelector("p.info-account");
	    	}
	    	
    	}