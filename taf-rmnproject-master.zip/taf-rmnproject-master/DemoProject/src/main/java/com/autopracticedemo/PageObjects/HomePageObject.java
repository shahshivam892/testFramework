package com.autopracticedemo.PageObjects;

import com.autopracticedemo.ElementProviders.HomePageElementProvider;
import com.taf.core.TestContext;
import com.taf.core.TestPage;
import com.taf.impl.selenium.SeleniumTestContext;

/**
 * The Class HomePageObject.
 */
public class HomePageObject extends TestPage {

    /** The selenium test context. */
    private final SeleniumTestContext seleniumTestContext;

    /** The sign up page element provider. */
    private HomePageElementProvider homePageElementProvider;

    /**
     * Instantiates a new sign up page.
     *
     * @param context
     *            the context
     */
    public HomePageObject(final TestContext context){
        super(context);
        seleniumTestContext = (SeleniumTestContext) context;
    }
    
    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestPage#intializeElementProvider()
     */
    @Override
    public void initializeElementProvider(){
        homePageElementProvider = new HomePageElementProvider(seleniumTestContext);
    }
    
    
          
    public void clickSignin(){
		     seleniumTestContext.clickButton(homePageElementProvider.getSignin());
		}
		
         
    public void clickEmail_create(){
		     seleniumTestContext.clickButton(homePageElementProvider.getEmail_create());
		}
		
         
    public void enterEmail_create(final String text){
		     seleniumTestContext.enterTextIn(homePageElementProvider.getEmail_create(),text);
		}
		
         
    public void clickSubmitCreategtspan(){
		     seleniumTestContext.clickButton(homePageElementProvider.getSubmitCreategtspan());
		}
		
         
    public void clickContactus(){
		     seleniumTestContext.clickButton(homePageElementProvider.getContactus());
		}
		
        
      }
    