package com.autopracticedemo.PageObjects;

import com.autopracticedemo.ElementProviders.LoginPageElementProvider;
import com.taf.core.TestContext;
import com.taf.core.TestPage;
import com.taf.impl.selenium.SeleniumTestContext;

/**
 * The Class LoginPageObject.
 */
public class LoginPageObject extends TestPage {

    /** The selenium test context. */
    private final SeleniumTestContext seleniumTestContext;

    /** The sign up page element provider. */
    private LoginPageElementProvider loginPageElementProvider;

    /**
     * Instantiates a new sign up page.
     *
     * @param context
     *            the context
     */
    public LoginPageObject(final TestContext context){
        super(context);
        seleniumTestContext = (SeleniumTestContext) context;
    }
    
    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestPage#intializeElementProvider()
     */
    @Override
    public void initializeElementProvider(){
        loginPageElementProvider = new LoginPageElementProvider(seleniumTestContext);
    }
    
    
          
    public void clickEmail(){
		     seleniumTestContext.clickButton(loginPageElementProvider.getEmail());
		}
		
         
    public void enterEmail(final String text){
		     seleniumTestContext.enterTextIn(loginPageElementProvider.getEmail(),text);
		}
		
         
    public void clickPasswd(){
		     seleniumTestContext.clickButton(loginPageElementProvider.getPasswd());
		}
		
         
    public void enterPasswd(final String text){
		     seleniumTestContext.enterTextIn(loginPageElementProvider.getPasswd(),text);
		}
		
         
    public void clickSubmitLogingtspan(){
		     seleniumTestContext.clickButton(loginPageElementProvider.getSubmitLogingtspan());
		}
		
         
    public String verifyTextPinfoaccount(){
		    return seleniumTestContext.getText(loginPageElementProvider.getPinfoaccount());
		}
		
        
        
    public void LoginFunc(String email,String passwd){
		    		    clickEmail();
		    		    enterEmail(email);
		    		    clickPasswd();
		    		    enterPasswd(passwd);
		    		    clickSubmitLogingtspan();
		    		}
		
      }
    