package com.autopracticedemo.ElementProviders;

import org.openqa.selenium.By;

import com.taf.core.PageElementProvider;
import com.taf.core.TestContext;
import com.taf.impl.selenium.SeleniumElementProvider;
import com.taf.impl.selenium.SeleniumTestContext;

/**
 * The Class ContactUsPageElementProvider.
 */
public class ContactUsPageElementProvider extends PageElementProvider {

    /** The selenium test context. */
    protected SeleniumTestContext seleniumTestContext;

    /** The selenium element provider. */
    protected SeleniumElementProvider seleniumElementProvider;

    /**
     * Instantiates a new base element provider.
     *
     * @param context
     *            the context
     */
    public ContactUsPageElementProvider(final TestContext context) {
        super(context);
        seleniumTestContext = (SeleniumTestContext) context;
        seleniumElementProvider = new SeleniumElementProvider(seleniumTestContext);
    }

			
		public Object getId_contact(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("id_contact"));
		        return seleniumElementProvider.getElementByID("id_contact");
	    	}
	    	
    			
		public Object getEmail(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("email"));
		        return seleniumElementProvider.getElementByID("email");
	    	}
	    	
    			
		public Object getId_order(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("id_order"));
		        return seleniumElementProvider.getElementByID("id_order");
	    	}
	    	
    			
		public Object getMessage(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.id("message"));
		        return seleniumElementProvider.getElementByID("message");
	    	}
	    	
    			
		public Object getSubmitMessagegtspan(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.cssSelector("#submitMessage"));
		        return seleniumElementProvider.getElementByCSSSelector("#submitMessage");
	    	}
	    	
    			
		public Object getPalertalertsuccess(){
		        seleniumTestContext.waitForElementToDisplayUsingBy(By.cssSelector("p.alert.alert-success"));
		        return seleniumElementProvider.getElementByCSSSelector("p.alert.alert-success");
	    	}
	    	
    	}