package com.autopracticedemo.PageObjects;

import com.autopracticedemo.ElementProviders.ContactUsPageElementProvider;
import com.taf.core.TestContext;
import com.taf.core.TestPage;
import com.taf.impl.selenium.SeleniumTestContext;

/**
 * The Class ContactUsPageObject.
 */
public class ContactUsPageObject extends TestPage {

    /** The selenium test context. */
    private final SeleniumTestContext seleniumTestContext;

    /** The sign up page element provider. */
    private ContactUsPageElementProvider contactUsPageElementProvider;

    /**
     * Instantiates a new sign up page.
     *
     * @param context
     *            the context
     */
    public ContactUsPageObject(final TestContext context){
        super(context);
        seleniumTestContext = (SeleniumTestContext) context;
    }
    
    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestPage#intializeElementProvider()
     */
    @Override
    public void initializeElementProvider(){
        contactUsPageElementProvider = new ContactUsPageElementProvider(seleniumTestContext);
    }
    
    
          
    public void clickId_contact(){
		     seleniumTestContext.clickButton(contactUsPageElementProvider.getId_contact());
		}
		
         
    public void selectId_contact(final String text){
		     seleniumTestContext.selectElementByVisibleText(contactUsPageElementProvider.getId_contact(),text);
		}
		
         
    public void clickEmail(){
		     seleniumTestContext.clickButton(contactUsPageElementProvider.getEmail());
		}
		
         
    public void enterEmail(final String text){
		     seleniumTestContext.enterTextIn(contactUsPageElementProvider.getEmail(),text);
		}
		
         
    public void clickId_order(){
		     seleniumTestContext.clickButton(contactUsPageElementProvider.getId_order());
		}
		
         
    public void enterId_order(final String text){
		     seleniumTestContext.enterTextIn(contactUsPageElementProvider.getId_order(),text);
		}
		
         
    public void clickMessage(){
		     seleniumTestContext.clickButton(contactUsPageElementProvider.getMessage());
		}
		
         
    public void enterMessage(final String text){
		     seleniumTestContext.enterTextIn(contactUsPageElementProvider.getMessage(),text);
		}
		
         
    public void clickSubmitMessagegtspan(){
		     seleniumTestContext.clickButton(contactUsPageElementProvider.getSubmitMessagegtspan());
		}
		
         
    public String verifyTextPalertalertsuccess(){
		    return seleniumTestContext.getText(contactUsPageElementProvider.getPalertalertsuccess());
		}
		
        
        
    public void ContactUsFunc(String id_contact,String email,String id_order,String message){
		    		    clickId_contact();
		    		    selectId_contact(id_contact);
		    		    clickEmail();
		    		    enterEmail(email);
		    		    clickId_order();
		    		    enterId_order(id_order);
		    		    clickMessage();
		    		    enterMessage(message);
		    		    clickSubmitMessagegtspan();
		    		}
		
      }
    