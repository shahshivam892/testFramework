package com.autopracticedemo.TestCases;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.autopracticedemo.PageObjects.ContactUsPageObject;
import com.autopracticedemo.PageObjects.HomePageObject;
import com.autopracticedemo.PageObjects.LoginPageObject;

public class AutopracticedemoTestCaseTestNgTest extends BaseTestNgTest {

	@Test(description = "This is Login", groups = { "Login", "Smoke", "Regression" })
	public void testLogin() {

		SoftAssert softassert = new SoftAssert();

		LoginPageObject loginpageobject = testApplication.get().getInstance(LoginPageObject.class);
		HomePageObject homepageobject = testApplication.get().getInstance(HomePageObject.class);

		homepageobject.clickSignin();
		ALLUREREPORTER.logInfo("Sign in");

		loginpageobject.LoginFunc("pjadhao1@gmail.com", "12345678");
		ALLUREREPORTER.logInfo("Please enter description.");

		softassert.assertEquals(loginpageobject.verifyTextPinfoaccount(),
				"Welcome to your account. Here you can manage all of your personal information and orders.");
		ALLUREREPORTER.logPass("Verified Login");

		softassert.assertAll();

	}

	@Test(description = "This is Contactus", groups = { "ContactUs", "Smoke", "Regression" })
	public void testContactus() {

		SoftAssert softassert = new SoftAssert();

		HomePageObject homepageobject = testApplication.get().getInstance(HomePageObject.class);
		ContactUsPageObject contactuspageobject = testApplication.get().getInstance(ContactUsPageObject.class);

		homepageobject.clickContactus();
		ALLUREREPORTER.logInfo("Contact us");

		contactuspageobject.ContactUsFunc("Customer service", "pratikjadhao1965@gmail.com", "123456", "1234");
		ALLUREREPORTER.logInfo("-- Choose -- Customer service Webmaster");

		softassert.assertEquals(contactuspageobject.verifyTextPalertalertsuccess(),
				"Your message has been successfully sent to our");
		ALLUREREPORTER.logPass("Verified Contact Us");

		softassert.assertAll();

	}

}