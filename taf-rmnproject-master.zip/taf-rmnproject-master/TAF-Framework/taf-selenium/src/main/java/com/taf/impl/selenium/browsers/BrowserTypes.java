package com.taf.impl.selenium.browsers;

import org.openqa.selenium.WebDriver;

/**
 * The Class BrowserTypes.
 */
public class BrowserTypes {

	/**
	 * Instantiates a Driver.
	 *
	 * @return the driver
	 * @throws Exception
	 */
	public static WebDriver getDriver() {
		String browserType="chrome";
		if(System.getProperty("browser.type")!=null)
		browserType = System.getProperty("browser.type");
		System.out.println(browserType);
		BrowserTypesEnum browser = BrowserTypesEnum.valueOf(browserType.toUpperCase());
		WebDriver webDriver = null;

		switch (browser) {
		case FIREFOX:
			webDriver = new FirefoxWebDriver().getDriver();
			break;
		case RESOLUTIONSCREEN:
			String width = System.getProperty("screen.width");
			String height = System.getProperty("screen.height");
			ResolutionBasedDriver resolutionDriver = new ResolutionBasedDriver();
			resolutionDriver.setWidth(Integer.parseInt(width));
			resolutionDriver.setHeight(Integer.parseInt(height));
			webDriver = resolutionDriver.getDriver();
			break;
		case DEVICE:
			String deviceName = System.getProperty("device.name");
			MobileEmulatorDriver mobileDriver = new MobileEmulatorDriver();
			mobileDriver.setDeviceName(deviceName);
			webDriver = mobileDriver.getDriver();
			break;
		case CHROME :
			webDriver = new ChromeWebDriver().getDriver();
			break;
//		case WEBVUE:
//			webDriver = new WebVueDriver().getDriver();
//			break;
//		case WPA:
//			webDriver = new WPADriver().getDriver();
//			break;
		default:
			webDriver = new ChromeWebDriver().getDriver();
			break;
		}

		return webDriver;
	}
}
