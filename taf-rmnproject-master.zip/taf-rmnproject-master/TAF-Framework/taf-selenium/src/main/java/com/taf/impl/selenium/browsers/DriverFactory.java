package com.taf.impl.selenium.browsers;

import org.openqa.selenium.WebDriver;

/**
 * Interface DriverFactory
 */
public interface DriverFactory {

	/**
	 *To Instantiates a Driver
	 * @return
	 */
	public WebDriver getDriver();

}
