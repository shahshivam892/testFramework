package com.taf.impl.selenium.browsers;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
/**
 * The Class ChromeWebDriver.
 *
 * @author surendrane
 */
public class ChromeWebDriver implements DriverFactory {

    WebDriver driver;

    /**
     * To Instantiates a ChromeDriver
     * @return
     */
    public WebDriver getDriver() {
        String chromePath =  System.getProperty("user.dir")+"/chromedriver.exe";
        
        System.setProperty("webdriver.chrome.driver", chromePath);
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        return driver;
    }
}