/**
 * 
 */
package com.taf.impl.selenium;

import org.openqa.selenium.WebDriver;

import com.taf.core.TestApplication;
import com.taf.core.TestEngine;
import com.taf.impl.selenium.browsers.BrowserTypes;

/**
 * The Class SeleniumTestEngine.
 *
 * @author surendrane
 */
public class SeleniumTestEngine extends TestEngine {

	/** The driver. */
	WebDriver driver;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.taf.core.TestEngine#start(java.lang.String)
	 */
	@Override
	public TestApplication start(String application) {
		driver = BrowserTypes.getDriver();

		TestApplication testApp = new TestApplication();
		SeleniumTestContext seleniumContext = new SeleniumTestContext();
		seleniumContext.setDriver(driver);
		testApp.setTestContext(seleniumContext);

		driver.get(application);
		return testApp;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.taf.core.TestEngine#stop()
	 */
	@Override
	public void stop() {
		driver.quit();
	}
}
