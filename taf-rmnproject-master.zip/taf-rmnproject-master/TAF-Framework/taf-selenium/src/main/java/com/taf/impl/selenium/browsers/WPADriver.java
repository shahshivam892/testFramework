//package com.taf.impl.selenium.browsers;
//
//import org.openqa.selenium.WebDriver;
//
//import com.qainnovation.wpaclient.driver.AnalyzerChromeDriver;
//
///**
// * The Class WPADriver.
// */
//public class WPADriver implements DriverFactory {
//	
//	/** The driver. */
//	WebDriver driver;
//
//	/**
//	 * Gets the driver.
//	 *
//	 * @return the driver
//	 */
//	@Override
//	public WebDriver getDriver() {
////		String wpaHost=System.getProperty("wpa.host");
////		String wpaPort=System.getProperty("wpa.port");
//		String wpaHost="127.0.0.1";
//		String wpaPort="8086";
//
//		AnalyzerChromeDriver analyzerDriver = new AnalyzerChromeDriver();
//		driver = analyzerDriver.initializeDriver(wpaHost, wpaPort);
//		return driver;
//	}
//}
