//package com.taf.impl.selenium.browsers;
//
//import org.openqa.selenium.WebDriver;
//
//import com.qainnovation.webvuejavaclient.WebVueChromeDriver;
//import com.qainnovation.webvuejavaclient.model.Webvueclient;
//import com.qainnovation.webvuejavaclient.services.InitializeWebVue;
//
///**
// * The Class WebVueDriver.
// */
//public class WebVueDriver implements DriverFactory {
//
//	/** The driver. */
//	WebDriver driver;
//
//	/**
//	 * Gets the driver.
//	 *
//	 * @return the driver
//	 */
//	@Override
//	public WebDriver getDriver() {
//		WebVueChromeDriver webVueDriver = null;
////		String webVueHost=System.getProperty("webvue.host");
////		Integer webVuePort=Integer.parseInt(System.getProperty("webvue.port"));
////		String zapApiKey=System.getProperty("zap.apikey");
////		String zapMode=System.getProperty("zap.mode");
////		String zapPath=System.getProperty("szap.path");
////		String zapHost=System.getProperty("zap.host");
////		Integer zapPort=Integer.parseInt(System.getProperty("zap.port"));
////		String driverName=System.getProperty("driver.name");
//		String webVueHost="localhost";
//		Integer webVuePort=8585;
//		String zapApiKey="jb2708omogbspfqiolsn0an8hp";
//		String zapMode="default";
//		String zapPath="C:/Program Files/OWASP/Zed Attack Proxy";
//		String zapHost="localhost";
//		Integer zapPort=9090;
//		String driverName="chrome";
//		try {
//			Webvueclient webVueClient = new Webvueclient.Builder().setHost(webVueHost).setPort(webVuePort).build();
//
//			// Initialize the WebVue
//			InitializeWebVue initialize = new InitializeWebVue.Builder().setApikey(zapApiKey)
//					.setMode(zapMode).setPath(zapPath).setHost(zapHost)
//					.setPort(zapPort).build();
//
//			webVueClient.initializeWebVue(initialize);
//
//			webVueDriver = new WebVueChromeDriver(driverName);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		driver = webVueDriver.getDriver();
//		return driver;
//	}
//
//}
