/**
 * 
 */
package com.framework.taf.impl.winapp;

import org.openqa.selenium.By;

import com.taf.core.TestContext;
import com.taf.core.ToolElementProvider;

/**
 * @author surendrane
 *
 */
public class WinappElementProvider extends ToolElementProvider {

	WinappTestContext winappTestContext;

	public WinappElementProvider(TestContext context) {
		super(context);
		winappTestContext = (WinappTestContext) context;
	}

	/**
	 * To GetElementById
	 * @param id the id
	 * @return
	 */
	@Override
	public Object getElementByID(String id) {
		return winappTestContext.getDriver().findElement(By.id(id));
	}

	/**
	 * To Get Element By Name
	 * @param name the name
	 * @return
	 */
	@Override
	public Object getElementByName(String name) {
		return winappTestContext.getDriver().findElement(By.name(name));
	}

	/**
	 * To Get Element By Xpath
	 * @param xpath
	 * @return
	 */
	public Object getElementByXpath(String xpath) {
		return winappTestContext.getDriver().findElement(By.xpath(xpath));
	}

	/**
	 * To GetlementByLinkText
	 * @param linkText
	 * @return
	 */
	public Object getElementByLinkText(String linkText) {
		return winappTestContext.getDriver().findElement(By.linkText(linkText));
	}
}
