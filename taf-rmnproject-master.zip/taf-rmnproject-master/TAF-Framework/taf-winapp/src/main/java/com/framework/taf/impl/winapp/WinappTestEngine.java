/**
 * 
 */
package com.framework.taf.impl.winapp;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebElement;
import com.taf.core.TestApplication;
import com.taf.core.TestEngine;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.windows.WindowsDriver;

/**
 * The class AppiumAndroidEngine
 * 
 * @author surendrane
 *
 */
public class WinappTestEngine extends TestEngine {

	WindowsDriver<RemoteWebElement> driver;
	static AppiumDriverLocalService service;

	@Override
	public TestApplication start(String applicationPath) {
		TestApplication testApp = new TestApplication();
		WinappTestContext winappTestContext = new WinappTestContext();
		DesiredCapabilities capabilities = new DesiredCapabilities();
		try {
			capabilities.setCapability("app", applicationPath);
			capabilities.setCapability("platformName", "Windows");
			capabilities.setCapability("deviceName", "WindowsPC");

			driver = new WindowsDriver<RemoteWebElement>(new URL("http://127.0.0.1:4723"), capabilities);

			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

			winappTestContext.setDriver(driver);
			testApp.setTestContext(winappTestContext);

		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

		return testApp;
	}

	@Override
	public void stop() {
		driver.quit();
	}

	public URL getServiceUrl() {
		return service.getUrl();
	}

}