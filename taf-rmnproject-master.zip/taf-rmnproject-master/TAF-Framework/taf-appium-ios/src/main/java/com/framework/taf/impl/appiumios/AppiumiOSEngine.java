/**
 *
 */
package com.framework.taf.impl.appiumios;

import java.io.File;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.framework.taf.impl.appiumios.models.AppiumiOSCapabilities;
import com.framework.taf.impl.appiumios.utils.AppiumiOSServer;
import com.taf.core.TestApplication;
import com.taf.core.TestEngine;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;

/**
 * @author surendrane
 *
 */
public class AppiumiOSEngine extends TestEngine {

    IOSDriver<WebElement> driver;
    static AppiumDriverLocalService service;
    AppiumiOSCapabilities appiumiOSCapabilities;
    AppiumiOSServer appiumServer;

    @Override
    public TestApplication start(String applicationPath) {

        try {
            service = AppiumDriverLocalService.buildDefaultService();
            service.start();
        } catch (Exception e) {
            appiumServer = new AppiumiOSServer();
            int port = 4723;
            if (!appiumServer.checkIfServerIsRunnning(port)) {
                appiumServer.startServer();
                appiumServer.stopServer();
            } else {
                System.out.println("Appium Server already running on Port - " + port);
            }
        }

        File app = new File(applicationPath);

        DesiredCapabilities capabilities = new DesiredCapabilities();
        if (!appiumiOSCapabilities.getDeviceName().isEmpty()) {
            capabilities.setCapability("deviceName", appiumiOSCapabilities.getDeviceName());
        }
        //capabilities.setCapability("app", app.getAbsolutePath());
        capabilities.setCapability("appPackage", appiumiOSCapabilities.getAppPackage());
        capabilities.setCapability("appActivity", appiumiOSCapabilities.getAppActivity());
        capabilities.setCapability("autoDismissAlerts", true);
        capabilities.setCapability("unicodeKeyboard", true);
        capabilities.setCapability("resetKeyboard", true);
        if (!appiumiOSCapabilities.getUdid().isEmpty()) {
            capabilities.setCapability("udid", appiumiOSCapabilities.getUdid());
        }
        driver = new IOSDriver<WebElement>(getServiceUrl(), capabilities);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        TestApplication testApp = new TestApplication();
        AppiumiOSContext appiumiOSContext = new AppiumiOSContext();
        appiumiOSContext.setDriver(driver);
        testApp.setTestContext(appiumiOSContext);

        return testApp;
    }

    @Override
    public void stop() {
        driver.quit();
        if (service != null) {
            service.stop();
        } else {
            appiumServer.stopServer();
        }
    }

    public URL getServiceUrl() {
        return service.getUrl();
    }

    public AppiumiOSCapabilities getiOSCapabilities() {
        return appiumiOSCapabilities;
    }

    public void setiOSCapabilities(AppiumiOSCapabilities pAppiumiOSCapabilities) {
        this.appiumiOSCapabilities = pAppiumiOSCapabilities;
    }
}