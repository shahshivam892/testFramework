/**
 * 
 */
package com.framework.taf.impl.appiumios;

import org.openqa.selenium.By;

import com.taf.core.TestContext;
import com.taf.core.ToolElementProvider;

/**
 * @author surendrane
 *
 */
public class AppiumiOSElementProvider extends ToolElementProvider {

	AppiumiOSContext appiumiOSContext;

	public AppiumiOSElementProvider(TestContext context) {
		super(context);
		appiumiOSContext = (AppiumiOSContext) context;
	}

	@Override
	public Object getElementByID(String id) {
		return appiumiOSContext.getDriver().findElement(By.id(id));
	}

	@Override
	public Object getElementByName(String name) {
		return appiumiOSContext.getDriver().findElement(By.name(name));
	}

	public Object getElementByXpath(String xpath) {
		return appiumiOSContext.getDriver().findElement(By.xpath(xpath));
	}

	public Object getElementByLinkText(String linkText) {
		return appiumiOSContext.getDriver().findElement(By.linkText(linkText));
	}
}
