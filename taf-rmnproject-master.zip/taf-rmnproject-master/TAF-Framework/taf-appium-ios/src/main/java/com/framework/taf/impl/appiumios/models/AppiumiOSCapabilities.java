/**
 *
 */
package com.framework.taf.impl.appiumios.models;

/**
 * @author surendrane
 *
 */
public class AppiumiOSCapabilities {

    static final String PLATFORM_NAME = "iOS";

    String deviceName = "";
    String platformVersion = "";
    String appPackage;
    String appActivity;
    String udid = "";
    String browserName = "";
    String platformName = PLATFORM_NAME;
    String app = "";

    public String getUdid() {
        return udid;
    }

    public void setUdid(String udid) {
        this.udid = udid;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getPlatformVersion() {
        return platformVersion;
    }

    public void setPlatformVersion(String platformVersion) {
        this.platformVersion = platformVersion;
    }

    public String getAppPackage() {
        return appPackage;
    }

    public void setAppPackage(String appPackage) {
        this.appPackage = appPackage;
    }

    public String getAppActivity() {
        return appActivity;
    }

    public void setAppActivity(String appActivity) {
        this.appActivity = appActivity;
    }

    public String getBrowserName() {
        return browserName;
    }

    public void setBrowserName(String browserName) {
        this.browserName = browserName;
    }

    public String getPlatformName() {
        return platformName;
    }

    public String getApp() {
        return platformName;
    }

    public String setApp(String path) {
        return platformName;
    }

    public void setPlatformName(String platformName) {
        this.platformName = platformName;
    }

    public String getAutomationName() {
        return platformName;
    }

    public String setAutomationName(String path) {
        return platformName;
    }

    public String getXcodeOrgId() {
        return platformName;
    }

    public String setXcodeOrgId(String path) {
        return platformName;
    }

    public String getXcodeSigningId() {
        return platformName;
    }

    public String setXcodeSigningId(String path) {
        return platformName;
    }
}
