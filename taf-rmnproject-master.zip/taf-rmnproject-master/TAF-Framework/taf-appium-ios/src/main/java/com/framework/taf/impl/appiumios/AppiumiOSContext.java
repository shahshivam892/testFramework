/**
 *
 */
package com.framework.taf.impl.appiumios;

import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.taf.core.TestContext;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

import java.time.Duration;

/**
 * @author surendrane
 *
 */
public class AppiumiOSContext implements TestContext {

    IOSDriver<WebElement> driver;

    public WebDriver getDriver() {
        return driver;
    }

    public void setDriver(IOSDriver<WebElement> IOSDriver) {
        this.driver = IOSDriver;
    }

    public void navigateTo(String url) {

    }

    public void enterTextIn(Object pageElement, String text) {
        ((IOSElement) pageElement).sendKeys(text);
    }

    public void clickButton(Object pageElement) {
        ((IOSElement) pageElement).submit();
    }

    public void waitFor(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
        }
    }

    public void close() {

    }

    public void takeScreenShot(String pageTitle) {

    }

    public String getPageTitle() {

        return null;
    }

    public String getText(Object pageElement) {
        return ((IOSElement) pageElement).getText();
    }

    public void clearTextBox(Object pageElement) {
    }

    public String getAttributeValue(Object pageElement, String attributeName) {
        return ((IOSElement) pageElement).getAttribute(attributeName);
    }

    public void click(Object pageElement) {
        ((IOSElement) pageElement).click();
    }

    public void clear(Object pageElement) {
        ((IOSElement) pageElement).clear();
    }

    public boolean isDisplayed(Object pageElement) {
        return ((IOSElement) pageElement).isDisplayed();
    }

    public void runAppInBackGnd() {
        try {
            driver.runAppInBackground(Duration.ofSeconds(1));
        } catch (Exception e) {
        }
    }

    public void hideKeyBoard() {
        driver.hideKeyboard();
    }

    public boolean waitForElementToBeClickableUsingObject(Object pageObject) {
        return false;
    }

    public boolean waitForElementToDisplay(Object pageObject) {
        return false;
    }

    public final void scrollDown() {
        Dimension dimensions = driver.manage().window().getSize();
        Double screenHeightStart = dimensions.getHeight() * 0.5;
        int scrollStart = screenHeightStart.intValue();
        System.out.println("s=" + scrollStart);
        Double screenHeightEnd = dimensions.getHeight() * 0.2;
        int scrollEnd = screenHeightEnd.intValue();
        new TouchAction<>((PerformsTouchActions) driver).press(PointOption.point(0, scrollStart))
                .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2))).moveTo(PointOption.point(scrollStart, scrollEnd)).release().perform();
    }

    public void waitForElement(Object pageElement) {
        IOSElement IOSElement = (IOSElement) pageElement;
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOf(IOSElement));
    }
}