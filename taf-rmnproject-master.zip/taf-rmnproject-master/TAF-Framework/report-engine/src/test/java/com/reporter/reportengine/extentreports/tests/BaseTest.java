/**
 * 
 */
package com.reporter.reportengine.extentreports.tests;

import java.lang.reflect.Method;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.reporter.reportengine.Report;
import com.reporter.reportengine.ReportEngine;
import com.reporter.reportengine.core.Reporter;

/**
 * The Class BaseTest.
 *
 * @author surendrane
 */
public class BaseTest {

	protected static Reporter reporter;

	/**
	 * Sets the up for suite.
	 */
	@BeforeSuite
	public void setUpForSuite() {
		reporter = ReportEngine.initializeReporter(Report.EXTENT_REPORT, "MyReport");
	}

	/**
	 * Tear down suite.
	 */
	@AfterSuite
	public void tearDownSuite() {

	}

	/**
	 * Sets the up.
	 */
	@BeforeMethod
	public void setUp(Method method) {
		reporter.createNewAndAssignTest(method.getName());
	}

	/**
	 * Tear down.
	 */
	@AfterMethod
	public void tearDown() {
		reporter.endOrCloseTest();
	}
}
