package com.reporter.reportengine.allurereports.tests;


import java.io.File;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestAllureReports extends BaseTest {

	@Test(groups = "Success")
	public void test1() {
		reporter.logPass("Testing Pass...");
		reporter.logPass("Test it");
		reporter.addFileToReport(new File("06ab1306-7af4-4dcf-9f56-2b0c221440ea-container.json").getAbsolutePath());
		reporter.takeScreenshot("AppAnalyzer.PNG");
	}

	@Test(enabled=false, groups = "Failure")
	public void test2() {
		Assert.fail("Failed....");
	}
}