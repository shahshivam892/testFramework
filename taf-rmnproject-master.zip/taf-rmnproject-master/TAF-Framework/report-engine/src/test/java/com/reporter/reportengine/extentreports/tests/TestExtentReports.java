package com.reporter.reportengine.extentreports.tests;

import org.junit.Assert;
import org.testng.annotations.Test;

public class TestExtentReports extends BaseTest{
	
	@Test
	public void test1()
	{
		reporter.logPass("Testing Pass...");
	}
	
	@Test(enabled=false)
	public void test2()
	{
		reporter.logFail("Testing Fail...");
		Assert.fail();
	}

}
