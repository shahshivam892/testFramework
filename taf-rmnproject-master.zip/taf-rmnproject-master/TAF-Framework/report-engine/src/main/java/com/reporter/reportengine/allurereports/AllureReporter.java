/**
 * 
 */
package com.reporter.reportengine.allurereports;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.reporter.reportengine.core.Reporter;

import io.qameta.allure.Allure;
import io.qameta.allure.Attachment;
import io.qameta.allure.Step;

/**
 * @author surendrane
 *
 */
public class AllureReporter implements Reporter {

	@Step("Pass: Message - {0}")
	public void logPass(final String message) {
	}

	@Step("{0}")
	public void logFail(final String message) {
	}

	@Step("{0}")
	public void logInfo(final String message) {
	}

	public void initializeReportEngine(String outputPath) {
	}

	public void createNewAndAssignTest(String testName) {
	}

	public void endOrCloseTest() {
	}

	public void closeReportEngine() {
	}

	public void takeScreenshot(final String stringPath) {
		try {
			String path = new StringBuilder(System.getProperty("user.dir")).append("/").append("snapshot").append("/")
					.append(stringPath).toString();
			saveScreenshot(Files.readAllBytes(Paths.get(path)));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Attachment(value = "Page screenshot", type = "image/png")
	public byte[] saveScreenshot(byte[] screenShot) {
		return screenShot;
	}

	public void addFileToReport(String filePath) {
		InputStream targetStream;
		try {
			targetStream = new FileInputStream(new File(filePath));
			Allure.addAttachment("Attached File", targetStream);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void addCategories(String[] categories) {
	}

	@Step("{0}")
	public void logSkip(String message) {
		// TODO Auto-generated method stub

	}

}
