/**
 * 
 */
package com.reporter.reportengine;

/**
 * The Enum Reporter.
 *
 * @author surendrane
 */
public enum Report {

	/** The extent report. */
	EXTENT_REPORT,
	/** The allure report. */
	ALLURE_REPORT
}
