/**
 * 
 */
package com.reporter.reportengine;

import com.reporter.reportengine.allurereports.AllureReporter;
import com.reporter.reportengine.core.Reporter;
import com.reporter.reportengine.extentreports.ExtentReporter;

/**
 * The Class ReportEngine.
 *
 * @author surendrane
 */
public class ReportEngine {

	/**
	 * Initialize reporter.
	 *
	 * @param report the report
	 * @param outputPath the output path
	 * @return the reporter
	 */
	public static Reporter initializeReporter(final Report report, final String outputPath) {

		Reporter reporter;

		switch (report) {
		case EXTENT_REPORT:
			reporter = new ExtentReporter();
			reporter.initializeReportEngine(outputPath);
			break;

		case ALLURE_REPORT:
			reporter = new AllureReporter();
			reporter.initializeReportEngine(outputPath);
			break;

		default:
			reporter = new ExtentReporter();
			reporter.initializeReportEngine(outputPath);
			break;
		}

		return reporter;
	}
}
