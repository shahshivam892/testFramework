/**
 * 
 */
package com.framework.taf.impl.appiumandroid;

import java.io.File;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.framework.taf.impl.appiumandroid.models.AppiumAndroidCapabilities;
import com.framework.taf.impl.appiumandroid.utils.AppiumAndroidServer;
import com.taf.core.TestApplication;
import com.taf.core.TestEngine;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;

/**
 * The class AppiumAndroidEngine
 * @author surendrane
 *
 */
public class AppiumAndroidEngine extends TestEngine {

	AndroidDriver<WebElement> driver;
	static AppiumDriverLocalService service;
	AppiumAndroidCapabilities appiumAndroidCapabilities;
	AppiumAndroidServer appiumServer;

	@Override
	public TestApplication start(String applicationPath) {

		try {
			service = AppiumDriverLocalService.buildDefaultService();
			service.start();
		} catch (Exception e) {
			appiumServer = new AppiumAndroidServer();
			int port = 4723;
			if (!appiumServer.checkIfServerIsRunnning(port)) {
				appiumServer.startServer();
				appiumServer.stopServer();
			} else {
				System.out.println("Appium Server already running on Port - " + port);
			}
		}

	/*	File app = new File(applicationPath);*/

		DesiredCapabilities capabilities = new DesiredCapabilities();
		if (!appiumAndroidCapabilities.getDeviceName().isEmpty()) {
			capabilities.setCapability("deviceName", appiumAndroidCapabilities.getDeviceName());
		}
		/*capabilities.setCapability("app", app.getAbsolutePath());*/
		capabilities.setCapability("appPackage", appiumAndroidCapabilities.getAppPackage());
		capabilities.setCapability("appActivity", appiumAndroidCapabilities.getAppActivity());
		capabilities.setCapability("autoGrantPermissions", true);
		if (!appiumAndroidCapabilities.getUdid().isEmpty()) {
			capabilities.setCapability("udid", appiumAndroidCapabilities.getUdid());
		}
		driver = new AndroidDriver<WebElement>(getServiceUrl(), capabilities);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		TestApplication testApp = new TestApplication();
		AppiumAndroidContext appiumAndroidContext = new AppiumAndroidContext();
		appiumAndroidContext.setDriver(driver);
		testApp.setTestContext(appiumAndroidContext);

		return testApp;
	}

	@Override
	public void stop() {
		driver.quit();
		if (service != null) {
			service.stop();
		} else {
			appiumServer.stopServer();
		}
	}

	public URL getServiceUrl() {
		return service.getUrl();
	}

	public AppiumAndroidCapabilities getAndroidCapabilities() {
		return appiumAndroidCapabilities;
	}

	public void setAndroidCapabilities(AppiumAndroidCapabilities pAppiumAndroidCapabilities) {
		this.appiumAndroidCapabilities = pAppiumAndroidCapabilities;
	}
}