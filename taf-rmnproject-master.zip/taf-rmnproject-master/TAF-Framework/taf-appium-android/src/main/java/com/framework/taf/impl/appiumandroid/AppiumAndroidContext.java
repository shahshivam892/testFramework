/**
 *
 */
package com.framework.taf.impl.appiumandroid;

import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.aspectj.util.FileUtil;
import org.openqa.selenium.*;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.taf.core.TestContext;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

/**
 * @author surendrane
 */
public class AppiumAndroidContext implements TestContext {

    AndroidDriver<WebElement> driver;

    public WebDriver getDriver() {
        return driver;
    }

    public void setDriver(AndroidDriver<WebElement> androidDriver) {
        this.driver = androidDriver;
    }

    /**
     * To Navigate
     * @param url the url
     */
    public void navigateTo(String url) {

    }

    /**
     * To EnterText
     * @param pageElement the page element
     * @param text the text
     */
    public void enterTextIn(Object pageElement, String text) {
        ((AndroidElement) pageElement).sendKeys(text);
    }

    /**
     * To Submit
     * @param pageElement the page element
     */
    public void clickButton(Object pageElement) {
        ((AndroidElement) pageElement).submit();
    }

    /**
     * To Wait
     * @param ms the ms
     */
    public void waitFor(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
        }
    }

    /**
     * To close
     */
    public void close() {

    }

    /**
     * To TakeScreenShot
     * @param pageTitle the page title
     */
    public void takeScreenShot(String pageTitle) {
        try {
            File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtil.copyFile(source, new File("snapshot/" + pageTitle));
        } catch (Exception e) {
            e.getMessage();
        }
    }

    /**
     * To Get PageTitle
     * @return
     */
    public String getPageTitle() {

        return null;
    }

    /**
     * To GetText of WebElement
     * @param pageElement the page element
     * @return
     */
    public String getText(Object pageElement) {
        return ((AndroidElement) pageElement).getText();
    }

    /**
     * To ClearTextField
     * @param pageElement the page element
     */
    public void clearTextBox(Object pageElement) {

    }

    /**
     * To GetAttributeValue
     * @param pageElement the page element
     * @param attributeName the attribute name
     * @return
     */
    public String getAttributeValue(Object pageElement, String attributeName) {

        return null;
    }

    /**
     * To Click Object
     * @param pageElement the page element
     */
    public void click(Object pageElement) {
        ((AndroidElement) pageElement).click();
    }

    /**
     * To clear Object
     * @param pageElement the page element
     */
    public void clear(Object pageElement) {
        ((AndroidElement) pageElement).clear();
    }

    /**
     * To Verify Displayed Object
     * @param pageElement the page element
     * @return
     */
    public boolean isDisplayed(Object pageElement) {
        return ((AndroidElement) pageElement).isDisplayed();
    }

    /**
     * To Wait For Object
     * @param pageElement
     */
    public void waitForElement(Object pageElement) {
        AndroidElement androidElement = (AndroidElement) pageElement;
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOf(androidElement));
    }

    /**
     * To openNotification
     */
    public void openNotifications() {
        driver.openNotifications();
    }

    /**
     * To Switch TO Frame
     * @param pageElement
     */
    public void switchToFrameByWebElement(Object pageElement) {
        driver.switchTo().frame((AndroidElement) pageElement);
    }

    /**
     * To RunAppInBackground
     */
    public void runAppInBackGnd() {
        try {
            driver.runAppInBackground(Duration.ofSeconds(1));
        } catch (Exception e) {
        }
    }

    /**
     * To ScrollDown
     */
    public final void scrollDown() {
        Dimension dimensions = driver.manage().window().getSize();
        Double screenHeightStart = dimensions.getHeight() * 0.5;
        int scrollStart = screenHeightStart.intValue();
        System.out.println("s=" + scrollStart);
        Double screenHeightEnd = dimensions.getHeight() * 0.2;
        int scrollEnd = screenHeightEnd.intValue();
        new TouchAction<>((PerformsTouchActions) driver).press(PointOption.point(0, scrollStart))
                .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2))).moveTo(PointOption.point(scrollStart, scrollEnd)).release().perform();
    }

    /**
     * To HideKeyboard
     */
    public void hideKeyBoard() {
        try {
            driver.hideKeyboard();
        } catch (Throwable th) {
            System.out.println("No keyboard ");
        }
    }

    /**
     * Wait for element to be clickable using object.
     *
     * @param pageObject
     *            the page object
     * @return true, if successful
     */
    public boolean waitForElementToBeClickableUsingObject(final Object pageObject) {
        final WebDriverWait wait = new WebDriverWait(driver, 10);
        boolean isElementClickable = false;
        try {
            wait.until(ExpectedConditions.elementToBeClickable((WebElement) pageObject));
            isElementClickable = true;
        } catch (final TimeoutException timeoutException) {
            isElementClickable = false;
        }
        return isElementClickable;
    }


    /**
     * Wait for element to be enable.
     *
     * @param pageObject
     *            the page object by
     * @return true, if successful
     */
    public boolean waitForElementToBeEnabled(final Object pageObject) {
        final WebDriverWait wait = new WebDriverWait(driver,10);
        boolean isElementEnabled = false;
        try {
            wait.until(ExpectedConditions.visibilityOf((WebElement) pageObject));
            isElementEnabled = true;
        } catch (final TimeoutException timeoutException) {
            isElementEnabled = false;
        }
        return isElementEnabled;
    }

    /**
     * Wait for element to display.
     *
     * @param pageObject
     *            the page object
     * @return true, if successful
     */
    public boolean waitForElementToDisplay(final Object pageObject) {
        final WebDriverWait wait = new WebDriverWait(driver, 10);
        boolean isElementDisplayed = false;
        try {
            wait.until(ExpectedConditions.visibilityOf((WebElement) pageObject));
            isElementDisplayed = true;
        } catch (final TimeoutException timeoutException) {
            isElementDisplayed = false;
        }
        return isElementDisplayed;
    }
}
