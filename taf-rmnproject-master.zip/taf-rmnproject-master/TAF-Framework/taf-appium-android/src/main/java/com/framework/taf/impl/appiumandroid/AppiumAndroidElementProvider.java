/**
 * 
 */
package com.framework.taf.impl.appiumandroid;

import org.openqa.selenium.By;

import com.taf.core.TestContext;
import com.taf.core.ToolElementProvider;

/**
 * @author surendrane
 *
 */
public class AppiumAndroidElementProvider extends ToolElementProvider {

	AppiumAndroidContext appiumAndroidContext;

	public AppiumAndroidElementProvider(TestContext context) {
		super(context);
		appiumAndroidContext = (AppiumAndroidContext) context;
	}

	/**
	 * To GetElementById
	 * @param id the id
	 * @return
	 */
	@Override
	public Object getElementByID(String id) {
		return appiumAndroidContext.getDriver().findElement(By.id(id));
	}

	/**
	 * To Get Element By Name
	 * @param name the name
	 * @return
	 */
	@Override
	public Object getElementByName(String name) {
		return appiumAndroidContext.getDriver().findElement(By.name(name));
	}

	/**
	 * To Get Element By Xpath
	 * @param xpath
	 * @return
	 */
	public Object getElementByXpath(String xpath) {
		return appiumAndroidContext.getDriver().findElement(By.xpath(xpath));
	}

	/**
	 * To GetlementByLinkText
	 * @param linkText
	 * @return
	 */
	public Object getElementByLinkText(String linkText) {
		return appiumAndroidContext.getDriver().findElement(By.linkText(linkText));
	}
}
