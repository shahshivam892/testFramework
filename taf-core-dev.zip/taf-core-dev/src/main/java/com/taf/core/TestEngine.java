/**
 * Engine Core 
 */
package com.taf.core;

/**
 * The Class TestEngine.
 *
 * @author surendrane
 */
public abstract class TestEngine {
	
	/** The Test app. */
	public static TestApplication TestApp = null;
	
	/**
	 * Gets the test app.
	 *
	 * @return the test app
	 */
	public TestApplication getTestApp() {
		return TestApp;
	}
	
	/**
	 * Sets the test app.
	 *
	 * @param testApp the new test app
	 */
	public static void setTestApp(TestApplication testApp) {
		TestApp = testApp;
	}
	
	/**
	 * Start.
	 *
	 * @param application the application
	 * @return the test application
	 */
	public abstract TestApplication start(String application);
	
	/**
	 * Stop.
	 */
	public abstract void stop();
	
}
