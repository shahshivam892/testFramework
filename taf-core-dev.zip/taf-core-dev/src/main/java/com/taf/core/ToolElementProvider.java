/**
 * Abstract Class of ToolElementProvider
 */
package com.taf.core;

/**
 * The Class ToolElementProvider.
 *
 * @author surendrane
 */
public abstract class ToolElementProvider {
	
	/**
	 * Instantiates a new tool element provider.
	 *
	 * @param context the context
	 */
	public ToolElementProvider(TestContext context)
	{		
	}
	
	/**
	 * Gets the element by ID.
	 *
	 * @param id the id
	 * @return the element by ID
	 */
	public abstract Object getElementByID(String id);
	
	/**
	 * Gets the element by name.
	 *
	 * @param name the name
	 * @return the element by name
	 */
	public abstract Object getElementByName(String name);
}
