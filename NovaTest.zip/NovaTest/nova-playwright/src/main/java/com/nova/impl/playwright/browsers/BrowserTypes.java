package com.nova.impl.playwright.browsers;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Playwright;

/**
 * The Class BrowserTypes.
 */
public class BrowserTypes {

	/**
	 * Instantiates a Driver.
	 *
	 * @return the driver
	 */
	public static Browser getDriver() {

		String browserType = System.getProperty("browser.type");
		if (browserType != null) {

			if (browserType.equalsIgnoreCase("Firefox")) {
				return Playwright.create().firefox().launch(new BrowserType.LaunchOptions().setHeadless(false));
			} else if (browserType.equalsIgnoreCase("WebKit")) {
				return Playwright.create().webkit().launch(new BrowserType.LaunchOptions().setHeadless(false));
			}
//			else if(browserType.equalsIgnoreCase("Device")) {
//				Playwright.create().devices();
//			}
		}
		return Playwright.create().chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
	}
}
