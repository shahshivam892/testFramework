package com.nova.impl.playwright;

import com.microsoft.playwright.Browser;
import com.nova.core.TestApplication;
import com.nova.core.TestEngine;
import com.nova.impl.playwright.browsers.BrowserTypes;

/**
 * The Class PlaywrightTestEngine.
 */
public class PlaywrightTestEngine extends TestEngine {

	/** The browser. */
	Browser browser;

	/**
	 * Start.
	 *
	 * @param application the application
	 * @return the test application
	 */
	@Override
	public TestApplication start(String application) {
		browser = BrowserTypes.getDriver();

		TestApplication testApp = new TestApplication();
		PlaywrightTestContext playwrightContext = new PlaywrightTestContext();
		playwrightContext.setBrowser(browser);
		playwrightContext.setPage(browser.newPage());
		testApp.setTestContext(playwrightContext);

		playwrightContext.getPage().navigate(application);
		return testApp;
	}

	/**
	 * Stop.
	 */
	@Override
	public void stop() {
		browser.close();
	}

}
