package com.nova.impl.playwright;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.ElementHandle;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.ElementState;
import com.microsoft.playwright.options.WaitForSelectorState;
import com.nova.core.TestContext;

import java.nio.file.Paths;
import java.util.List;

/**
 * The Class PlaywrightTestContext.
 */
public class PlaywrightTestContext implements TestContext {

	/** The browser. */
	Browser browser;

	/** The page. */
	Page page;

	/**
	 * Gets the page.
	 *
	 * @return the page
	 */
	public Page getPage() {
		return page;
	}

	/**
	 * Sets the page.
	 *
	 * @param page the new page
	 */
	public void setPage(Page page) {
		this.page = page;
	}

	/**
	 * Gets the browser.
	 *
	 * @return the browser
	 */
	public Browser getBrowser() {
		return browser;
	}

	/**
	 * Sets the browser.
	 *
	 * @param browser the new browser
	 */
	public void setBrowser(Browser browser) {
		this.browser = browser;
	}

	/**
	 * Clear.
	 *
	 * @param pageElement the page element
	 */
	public void clear(Object pageElement) {
		((ElementHandle) pageElement).fill("");
	}

	/**
	 * Clear text box.
	 *
	 * @param pageElement the page element
	 */
	public void clearTextBox(Object pageElement) {
		((ElementHandle) pageElement).fill("");
	}

	/**
	 * Click.
	 *
	 * @param pageElement the page element
	 */
	public void click(Object pageElement) {
		((ElementHandle) pageElement).click();
	}

	/**
	 * Dblclick.
	 *
	 * @param pageElement the page element
	 */
	public void doubleClick(Object pageElement) {
		((ElementHandle) pageElement).dblclick();
	}
	/**
	 * Click button.
	 *
	 * @param pageElement the page element
	 */
	public void clickButton(Object pageElement) {
		((ElementHandle) pageElement).click();
	}

	/**
	 * Close.
	 */
	public void close() {
		page.close();
	}

	/**
	 * Enter text in.
	 *
	 * @param pageElement the page element
	 * @param text        the text
	 */
	public void enterTextIn(Object pageElement, String text) {
		((ElementHandle) pageElement).fill(text);

	}

	/**
	 * Gets the attribute value.
	 *
	 * @param pageElement the page element
	 * @param name        the name
	 * @return the attribute value
	 */
	public String getAttributeValue(Object pageElement, String name) {
		return ((ElementHandle) pageElement).getAttribute(name);
	}

	/**
	 * Gets the page title.
	 *
	 * @return the page title
	 */
	public String getPageTitle() {
		return page.title();
	}

	/**
	 * Gets the text.
	 *
	 * @param pageElement the page element
	 * @return the text
	 */
	public String getText(Object pageElement) {
		return ((ElementHandle) pageElement).textContent();
	}

	/**
	 * Navigate to.
	 *
	 * @param url the url
	 */
	public void navigateTo(String url) {
		page.navigate(url);
	}

	/**
	 * Send keys.
	 *
	 * @param pageElement the page element
	 * @param keys        the keys
	 */
	public void sendKeys(Object pageElement, Object keys) {
		((ElementHandle) pageElement).fill(keys.toString());
	}

	/**
	 * Move to element.
	 *
	 * @param pageElement the page element
	 */
	public void moveToElement(Object pageElement) {
		((ElementHandle) pageElement).hover();
	}

	/**
	 * Select element by visible text.
	 *
	 * @param pageElement the page element
	 * @param visibleText the visible text
	 */
	public void selectElementByVisibleText(Object pageElement, String visibleText) {
		((ElementHandle) pageElement).type(visibleText);
	}

	/**
	 * Click element within elements.
	 *
	 * @param pageElements the page elements
	 * @param innerText    the inner text
	 */
	public void clickElementWithinElements(Object pageElements, String innerText) {
		@SuppressWarnings("unchecked")
		List<ElementHandle> listOfelementHandle = (List<ElementHandle>) pageElements;
		for (ElementHandle elementHandle : listOfelementHandle) {
			if (elementHandle.textContent().equals(innerText)) {
				elementHandle.click();
				break;
			}
		}
	}

	/**
	 * Take screen shot.
	 *
	 * @param pageTitle the page title
	 */
	public void takeScreenShot(String pageTitle) {
		try {
			page.screenshot(new Page.ScreenshotOptions().setPath(Paths.get("snapshot/" + pageTitle + ".png")));

		} catch (Exception e) {
		}
	}

	/**
	 * Wait for.
	 *
	 * @param ms the ms
	 */
	public void waitFor(long ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Wait for element to display using selector.
	 *
	 * @param selector the selector
	 */
	public void waitForElementToDisplayUsingSelector(String selector) {
			if (selector.contains("link=")) {
				selector = new StringBuilder("xpath=//a[contains(text(),'").append(selector.split("link=")[1]).append("')]")
						.toString();
			}else if(selector.contains("name=")) {
				selector = new StringBuilder("xpath=//input[@name=\"").append(selector.split("name=")[1]).append("\"]")
						.toString();
			}
			page.waitForSelector(selector, new Page.WaitForSelectorOptions().setState(WaitForSelectorState.ATTACHED));
	}

	/**
	 * Wait for element to display.
	 *
	 * @param pageObject the page object
	 */
	public void waitForElementToDisplay(Object pageObject) {
		((ElementHandle) pageObject).waitForElementState(ElementState.STABLE);
	}

	/**
	 * Checks if is displayed.
	 *
	 * @param pageElement the page element
	 * @return true, if is displayed
	 */
	public boolean isDisplayed(Object pageElement) {
		return ((ElementHandle) pageElement).isVisible();
	}

	/**
	 * Scroll down.
	 */
	public void scrollDown() {
	}

	/**
	 * Hide key board.
	 */
	public void hideKeyBoard() {
	}

	/**
	 * Switch to frame.
	 *
	 * @param frameName the frame name
	 */
	public void switchToFrame(String frameName) {
		String url = page.frame(frameName).url();
		page.navigate(url);
	}

	/**
	 * Wait for element to be clickable using object.
	 *
	 * @param pageObject the page object
	 */
	public void waitForElementToBeClickableUsingObject(final Object pageObject) {
		((ElementHandle) pageObject).waitForElementState(ElementState.ENABLED);
	}

	/**
	 * Wait for element to be enabled.
	 *
	 * @param pageObject the page object
	 */
	public void waitForElementToBeEnabled(final Object pageObject) {
		((ElementHandle) pageObject).waitForElementState(ElementState.ENABLED);
	}

}
