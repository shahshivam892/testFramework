package com.nova.impl.selenium.browsers;

// TODO: Auto-generated Javadoc
/**
 * The Enum BrowserTypesEnum.
 */
public enum BrowserTypesEnum {

	/** The firefox. */
	FIREFOX,
	/** The resolutionscreen. */
	RESOLUTIONSCREEN,
	/** The chrome. */
	CHROME,
	/** The device. */
	DEVICE,
	/** The webvue. */
	WEBVUE,
	/** The wpa. */
	WPA
}
