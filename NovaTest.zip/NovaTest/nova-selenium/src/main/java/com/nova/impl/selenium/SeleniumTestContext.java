/**
 *
 */
package com.nova.impl.selenium;

//import com.taf.core.TestContext;
import com.nova.core.TestContext;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.util.List;


public class SeleniumTestContext implements TestContext {

    /**
     * The driver.
     */
    WebDriver driver;

    /**
     * Gets the driver.
     *
     * @return the driver
     */
    public WebDriver getDriver() {
        return driver;
    }

    /**
     * Sets the driver.
     *
     * @param driver the new driver
     */
    public void setDriver(WebDriver driver) {
        this.driver = driver;
    }

    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestContext#navigateTo(java.lang.String)
     */
    public void navigateTo(String url) {

        driver.get(url);
    }

    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestContext#enterTextIn(java.lang.Object, java.lang.String)
     */
    public void enterTextIn(Object pageElement, String text) {

        ((WebElement) pageElement).sendKeys(text);
    }

    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestContext#clickButton(java.lang.Object)
     */
    public void clickButton(Object pageElement) {

        ((WebElement) pageElement).click();
    }

    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestContext#waitFor(long)
     */
    public void waitFor(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestContext#close()
     */
    public void close() {

        driver.close();
    }

    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestContext#takeScreenShot(java.lang.String)
     */
    public void takeScreenShot(String pageTitle) {

        try {
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File("snapshot/" + pageTitle));

        } catch (Exception e) {
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestContext#getPageTitle()
     */
    public String getPageTitle() {

        return driver.getTitle();
    }

    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestContext#getText(java.lang.Object)
     */
    public String getText(Object pageElement) {
        return ((WebElement) pageElement).getText();
    }

    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestContext#clearTextBox(java.lang.Object)
     */
    public void clearTextBox(Object pageElement) {
        ((WebElement) pageElement).clear();
    }

    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestContext#getAttributeValue(java.lang.Object,
     * java.lang.String)
     */
    public String getAttributeValue(Object pageElement, String attributeName) {
        return ((WebElement) pageElement).getAttribute(attributeName);
    }

    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestContext#click(java.lang.Object)
     */
    public void click(Object pageElement) {
        ((WebElement) pageElement).click();
    }

    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestContext#clear(java.lang.Object)
     */
    public void clear(Object pageElement) {
        ((WebElement) pageElement).clear();
    }

    /**
     * Send keys.
     *
     * @param pageElement the page element
     * @param keys        the keys
     */
    public void sendKeys(Object pageElement, Object keys) {
        ((WebElement) pageElement).sendKeys((CharSequence[]) keys);
    }

    /**
     * Move to element.
     *
     * @param pageElement the page element
     */
    public void moveToElement(Object pageElement) {
        Actions actions = new Actions(getDriver());
        actions.moveToElement((WebElement) pageElement).build().perform();
    }

    /**
     * Select element by visible text.
     *
     * @param pageElement the page element
     * @param visibleText the visible text
     */
    public void selectElementByVisibleText(Object pageElement, String visibleText) {
        Select select = new Select((WebElement) pageElement);
        select.selectByVisibleText(visibleText);
    }

    /**
     * Click element within elements.
     *
     * @param pageElements the page elements
     * @param innerText    the inner text
     */
    public void clickElementWithinElements(Object pageElements, String innerText) {
        @SuppressWarnings("unchecked")
        List<WebElement> listOfWebElements = (List<WebElement>) pageElements;
        for (WebElement webElement : listOfWebElements) {
            if (webElement.getText().equals(innerText)) {
                webElement.click();
                break;
            }
        }
    }

    /**
     * Wait for element to display.
     *
     * @param pageObject the page object
     * @return true, if successful
     */
    public boolean waitForElementToDisplay(Object pageObject) {
        WebDriverWait wait = new WebDriverWait(driver, 5);
        boolean isElementDisplayed = false;
        try {
            wait.until(ExpectedConditions.visibilityOf((WebElement) pageObject));
            isElementDisplayed = true;
        } catch (TimeoutException timeoutException) {
            isElementDisplayed = false;
        }
        return isElementDisplayed;
    }

    /**
     * Wait for element to display using by.
     *
     * @param pageObjectBy the page object by
     * @return true, if successful
     */
    public boolean waitForElementToDisplayUsingBy(Object pageObjectBy) {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        boolean isElementDisplayed = false;
        try {
            wait.until(ExpectedConditions.presenceOfElementLocated((By) pageObjectBy));
            isElementDisplayed = true;
        } catch (TimeoutException timeoutException) {
            isElementDisplayed = false;
        }
        return isElementDisplayed;
    }

    /**
     * To Verify Displayed Object
     *
     * @param pageElement the page element
     * @return true, if present
     */
    public boolean isDisplayed(Object pageElement) {
        // TODO Auto-generated method stub
        return ((WebElement) pageElement).isDisplayed();
    }

    /**
     * To Scroll Down
     */
    public void scrollDown() {
        // TODO Auto-generated method stub
    }

    public void hideKeyBoard() {
    }

    /**
     * To Switch To Frame by Name
     *
     * @param frameName
     */
    public void switchToFrame(String frameName) {
        // TODO Auto-generated method stub
        driver.switchTo().frame(frameName);
    }

  /*  *//**
     * Wait for element to display.
     *
     * @param pageObject
     *            the page object
     * @return true, if successful
     *//*
    public boolean waitForElementToDisplay(final Object pageObject) {
        final WebDriverWait wait = new WebDriverWait(driver, 10);
        boolean isElementDisplayed = false;
        try {
            wait.until(ExpectedConditions.visibilityOf((WebElement) pageObject));
            isElementDisplayed = true;
        } catch (final TimeoutException timeoutException) {
            isElementDisplayed = false;
        }
        return isElementDisplayed;
    }*/



    /**
     * Wait for element to be clickable using object.
     *
     * @param pageObject
     *            the page object
     * @return true, if successful
     */
    public boolean waitForElementToBeClickableUsingObject(final Object pageObject) {
        final WebDriverWait wait = new WebDriverWait(driver, 10);
        boolean isElementClickable = false;
        try {
            wait.until(ExpectedConditions.elementToBeClickable((WebElement) pageObject));
            isElementClickable = true;
        } catch (final TimeoutException timeoutException) {
            isElementClickable = false;
        }
        return isElementClickable;
    }


    /**
     * Wait for element to be enable.
     *
     * @param pageObject
     *            the page object by
     * @return true, if successful
     */
    public boolean waitForElementToBeEnabled(final Object pageObject) {
        final WebDriverWait wait = new WebDriverWait(driver,10);
        boolean isElementEnabled = false;
        try {
            wait.until(ExpectedConditions.visibilityOf((WebElement) pageObject));
            isElementEnabled = true;
        } catch (final TimeoutException timeoutException) {
            isElementEnabled = false;
        }
        return isElementEnabled;
    }
}