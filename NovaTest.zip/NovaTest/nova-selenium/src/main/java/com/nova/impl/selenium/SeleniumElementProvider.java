/**
 *
 */
package com.nova.impl.selenium;

//import com.taf.core.TestContext;
//import com.taf.core.ToolElementProvider;
import com.nova.core.TestContext;
import com.nova.core.ToolElementProvider;
import org.openqa.selenium.By;


public class SeleniumElementProvider extends ToolElementProvider {

    /**
     * The pageobjects context.
     */
    SeleniumTestContext _seleniumContext;

    /**
     * Instantiates a new pageobjects element provider.
     *
     * @param context the context
     */
    public SeleniumElementProvider(TestContext context) {
        super(context);
        _seleniumContext = (SeleniumTestContext) context;
    }

    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.ToolElementProvider#getElementByID(java.lang.String)
     */
    @Override
    public Object getElementByID(String id) {
        // TODO Auto-generated method stub
        return _seleniumContext.getDriver().findElement(By.id(id));
    }

    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.ToolElementProvider#getElementByName(java.lang.String)
     */
    @Override
    public Object getElementByName(String name) {
        // TODO Auto-generated method stub
        return _seleniumContext.getDriver().findElement(By.name(name));
    }

    /**
     * Gets the element by xpath.
     *
     * @param xpath the xpath
     * @return the element by xpath
     */
    public Object getElementByXpath(String xpath) {
        return _seleniumContext.getDriver().findElement(By.xpath(xpath));
    }

    /**
     * Gets the element by link text.
     *
     * @param linkText the link text
     * @return the element by link text
     */
    public Object getElementByLinkText(String linkText) {
        return _seleniumContext.getDriver().findElement(By.linkText(linkText));
    }

    /**
     * Gets the element by partial link text.
     *
     * @param linkText the link text
     * @return the element by partial link text
     */
    public Object getElementByPartialLinkText(String linkText) {
        return _seleniumContext.getDriver().findElement(By.partialLinkText(linkText));
    }

    /**
     * Gets the element by CSS selector.
     *
     * @param css the css
     * @return the element by CSS selector
     */
    public Object getElementByCSSSelector(String css) {
        return _seleniumContext.getDriver().findElement(By.cssSelector(css));
    }

    /**
     * Gets the element by tag name.
     *
     * @param tagName the tag name
     * @return the element by tag name
     */
    public Object getElementByTagName(String tagName) {
        return _seleniumContext.getDriver().findElement(By.tagName(tagName));
    }

    /**
     * Gets the element from parent.
     *
     * @param elementBy the element by
     * @param childBy   the child by
     * @return the element from parent
     */
    public Object getElementFromParent(By elementBy, By childBy) {
        return _seleniumContext.getDriver().findElement(elementBy).findElement(By.xpath("//parent::div"))
                .findElement(childBy);
    }

    /**
     * Gets the text element by label.
     *
     * @param label the label
     * @return the text element by label
     */
    public Object getTextElementByLabel(String label) {
        return _seleniumContext.getDriver()
                .findElement(By.xpath("//label[contains(text(),\"" + label + "\")]//parent::div//input"));
    }

    /**
     * Gets the elements by xpath.
     *
     * @param xpath the xpath
     * @return the elements by xpath
     */
    public Object getElementsByXpath(String xpath) {
        return _seleniumContext.getDriver().findElements(By.xpath(xpath));
    }
}
