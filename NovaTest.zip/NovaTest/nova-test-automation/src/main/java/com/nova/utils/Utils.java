package com.nova.utils;

import com.nova.core.TestContext;
import com.nova.core.ToolElementProvider;
import com.nova.impl.playwright.PlaywrightElementProvider;
import com.nova.impl.playwright.PlaywrightTestContext;
import com.nova.impl.selenium.SeleniumElementProvider;
import com.nova.impl.selenium.SeleniumTestContext;

public class Utils {

    public static ToolElementProvider getToolElementProvider(TestContext context){
        if (context instanceof PlaywrightTestContext)
            return new PlaywrightElementProvider(context);
        else if (context instanceof SeleniumTestContext) {
            return new SeleniumElementProvider(context);
        }
        System.out.println("######## Unknown context ########");
        return null;
    }

}
