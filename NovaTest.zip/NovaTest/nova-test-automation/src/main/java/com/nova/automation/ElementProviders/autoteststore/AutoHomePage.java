package com.nova.automation.ElementProviders.autoteststore;

import com.nova.core.PageElementProvider;
import com.nova.core.TestContext;
import com.nova.core.ToolElementProvider;
import com.nova.impl.playwright.PlaywrightElementProvider;
import com.nova.impl.playwright.PlaywrightTestContext;
import com.nova.impl.selenium.SeleniumElementProvider;
import com.nova.impl.selenium.SeleniumTestContext;
import com.nova.utils.ConfigLoader;
import com.nova.utils.Utils;

public class AutoHomePage extends PageElementProvider {

    TestContext context;
    ToolElementProvider toolElementProvider;
    ConfigLoader configLoader = new ConfigLoader("src/main/resources/browser.properties");

    final String loginAndRegisterButton = "//a[text()='Login or register']";
    final String loginButton = "//button[@title='Login']";
    final String usernameFeild = "loginFrm_loginname";
    final String passwordFeild = "loginFrm_password";

    public AutoHomePage(TestContext context) {
        super(context);
        this.context = context;
        if (context instanceof PlaywrightTestContext){
            this.toolElementProvider = new PlaywrightElementProvider(context);
        } else if (context instanceof SeleniumTestContext) {
            this.toolElementProvider = new SeleniumElementProvider(context);
        }
        this.toolElementProvider = Utils.getToolElementProvider(context);
    }

    public Object getLoginAndRegisterButton(){
        return toolElementProvider.getElementByXpath(loginAndRegisterButton);
    }

    public Object getUsernameFeild(){
        return toolElementProvider.getElementByID(usernameFeild);
    }

    public Object getpasswordFeild(){
        return toolElementProvider.getElementByID(passwordFeild);
    }

    public Object getLoginButton(){
        return toolElementProvider.getElementByXpath(loginButton);
    }

}
