package com.nova.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigLoader {

    private final Properties properties = new Properties();

    // Constructor loads the file once
    public ConfigLoader(String filePath) {
        try (FileInputStream fis = new FileInputStream(filePath)) {
            properties.load(fis);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load properties file: " + filePath, e);
        }
    }

    // Fetch property by key
    public String get(String key) {
        return properties.getProperty(key);
    }

    // Fetch property with default value
    public String getOrDefault(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }

}
