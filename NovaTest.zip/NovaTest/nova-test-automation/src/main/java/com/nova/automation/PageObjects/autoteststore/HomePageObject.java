package com.nova.automation.PageObjects.autoteststore;


import com.nova.automation.ElementProviders.autoteststore.AutoHomePage;
import com.nova.core.TestContext;
import com.nova.core.TestPage;

public class HomePageObject extends TestPage {

    TestContext testContext;
    AutoHomePage autoHomePage;

    public HomePageObject(final TestContext context){
        super(context);
        testContext = context;
    }

    @Override
    public void initializeElementProvider(){
        autoHomePage = new AutoHomePage(testContext);
    }

    public void clickOnLoginAndRegisterButton(){
        testContext.click(autoHomePage.getLoginAndRegisterButton());
    }

    public void enterUsername(String username){
        testContext.enterTextIn(autoHomePage.getUsernameFeild(), username);
    }

    public void enterPassword(String password){
        testContext.enterTextIn(autoHomePage.getpasswordFeild(), password);
    }

    public void clickOnLoginButton(){
        testContext.click(autoHomePage.getLoginButton());
    }

}
