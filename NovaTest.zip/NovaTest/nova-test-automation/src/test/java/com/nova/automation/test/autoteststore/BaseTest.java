package com.nova.automation.test.autoteststore;

import com.nova.core.TestApplication;
import com.nova.core.TestEngine;
import com.nova.impl.playwright.PlaywrightTestEngine;
import com.nova.impl.selenium.SeleniumTestEngine;
import com.nova.reporter.reportengine.extentreports.ExtentReporter;
import com.nova.utils.ConfigLoader;
import com.opencsv.CSVReader;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.*;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class BaseTest {

    protected ThreadLocal<TestEngine> testEngine = new ThreadLocal<TestEngine>();
    protected ThreadLocal<TestApplication> testApplication = new ThreadLocal<TestApplication>();
	public static final ExtentReporter EXTENTREPORTER = new ExtentReporter();
//    public static final AllureReporter EXTENTREPORTER = new AllureReporter();

    String demoUrl = "https://automationteststore.com/";

    @BeforeSuite(alwaysRun = true)
    public void loadConfiguration() throws Exception {
        EXTENTREPORTER.initializeReportEngine("My_Report");
    }

    @BeforeMethod(alwaysRun = true)
    public void setUp(final Method method, ITestContext iTestContext) throws Exception {
        Test test = method.getAnnotation(Test.class);
        String firstGroupName=test.groups()[0];
        if(firstGroupName.equals("webvue")||firstGroupName.equals("wpa")) {
            System.setProperty("browser.type",firstGroupName);
        }
        switch (getAutomationTool()){
            case "PLAYWRIGHT":
                System.out.println("######## PLAYWRIGHT SELECTED ########");
                testEngine.set(new PlaywrightTestEngine());
                break;
            case "SELENIUM":
                System.out.println("######## SELENIUM SELECTED ########");
                testEngine.set(new SeleniumTestEngine());
                break;
            default:
                System.out.println("######## SELENIUM SELECTED (DEFAULT) ########");
                testEngine.set(new SeleniumTestEngine());
                break;
        }

        testApplication.set(testEngine.get().start(demoUrl));
        iTestContext.setAttribute("testApplication", testApplication);
        EXTENTREPORTER.createNewAndAssignTest(method.getName());
        EXTENTREPORTER.addCategories(test.groups());
    }

    @AfterMethod(alwaysRun = true)
    public void afterTest(final ITestResult result) throws Exception {
        if (result.getStatus() == ITestResult.FAILURE) {
            if (!Objects.isNull(result.getThrowable().getMessage())) {
                if (!result.getThrowable().getMessage().equals("")) {
                    EXTENTREPORTER.logFail(result.getThrowable().getMessage());
                }
            } else {
                EXTENTREPORTER.logSkip("Skipped Issue");
            }
            final long timeStamp = new Date().getTime();
//			testApplication.get().getTestContext().takeScreenShot("Failure_" + timeStamp + ".png");
            testApplication.get().getTestContext().takeScreenShot("Failure_" + timeStamp +".png");
            EXTENTREPORTER.takeScreenshot("Failure_" + timeStamp + ".png");
        }
        if (result.getStatus() == ITestResult.SKIP) {
            EXTENTREPORTER.logSkip(result.getThrowable().toString());
        }
        EXTENTREPORTER.endOrCloseTest();
        testEngine.get().stop();
    }

    /**
     * Tear down.
     */
    @AfterSuite(alwaysRun = true)
    public void tearDown() throws Exception {
        EXTENTREPORTER.closeReportEngine();
    }


    @DataProvider(name = "csvDataProvider")
    public String[][] dataProviderUsingCSV(final String fileName) {
        CSVReader reader = null;

        final List<String[]> neededRows = new ArrayList<String[]>();
        try {
            reader = new CSVReader(new FileReader(new File(fileName)));
            // List<String> columnHeaders = Arrays.asList(reader.readNext());
            final List<Integer> neededIndexes = new ArrayList<Integer>();
            final int numNeededCols = neededIndexes.size();
            for (String[] row = reader.readNext(); row != null; row = reader.readNext()) {
                final String[] neededRow = new String[numNeededCols];
                for (int i = 0; i < numNeededCols; ++i) {
                    neededRow[i] = row[neededIndexes.get(i)];
                }
                neededRows.add(neededRow);
            }
            reader.close();
        } catch (final UnsupportedEncodingException ex) {
        } catch (final IOException ex) {
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                }
            }
        }
        return neededRows.toArray(new String[neededRows.size()][]);
    }


    @SuppressWarnings({ "deprecation", "resource" })
    @DataProvider(name = "ExcelDataProvider", parallel = true)
    public static Object[][] readWorkFlowProgramsExcel() {
        Object[][] obj = null;
        final String fileLoc = System.getProperty("user.dir") + "/src/test/resources/WorkFlow.xlsx";

        final File file = new File(fileLoc);
        FileInputStream inputStream = null;
        Workbook workBook = null;
        try {
            inputStream = new FileInputStream(file);
            workBook = new XSSFWorkbook(inputStream);
            final Sheet sheet = workBook.getSheet("TestDataSheet");
            final int rownum = sheet.getPhysicalNumberOfRows();
            final int colnum = sheet.getRow(0).getLastCellNum();
            obj = new Object[rownum - 1][colnum];

            for (int i = 1; i < rownum; i++) {
                final Row row = sheet.getRow(i);
                for (int j = 0; j < colnum; j++) {
                    final Cell cell = row.getCell(j);
                    switch (cell.getCellType()) {
                        case Cell.CELL_TYPE_BOOLEAN:
                            obj[i - 1][j] = String.valueOf(cell.getBooleanCellValue());
                            break;
                        case Cell.CELL_TYPE_NUMERIC:
                            obj[i - 1][j] = NumberToTextConverter.toText(cell.getNumericCellValue());
                            break;
                        case Cell.CELL_TYPE_STRING:
                            obj[i - 1][j] = cell.getStringCellValue();
                            break;
                        case Cell.CELL_TYPE_BLANK:
                            obj[i - 1][j] = "";
                            break;
                        default:
                            break;
                    }

                }
            }
            return obj;
        } catch (final FileNotFoundException e) {
            e.printStackTrace();
        } catch (final IOException e) {
            e.printStackTrace();
        } finally {
            if (inputStream != null) {
                // inputStream.close();//TODO
            }
            if (workBook != null) {
                // workBook.close();
            }
        }
        return obj;
    }


    public void takeScreenshot(final String stringpath) {
        testApplication.get().getTestContext().takeScreenShot(stringpath);
        EXTENTREPORTER.takeScreenshot(stringpath);
    }

    public String getAutomationTool(){
        ConfigLoader configLoader = new ConfigLoader("src/main/resources/browser.properties");
        return configLoader.get("test.tool").trim().toUpperCase();
    }

}
