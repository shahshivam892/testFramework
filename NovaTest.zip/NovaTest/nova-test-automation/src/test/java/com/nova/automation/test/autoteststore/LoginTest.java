package com.nova.automation.test.autoteststore;

import com.nova.automation.PageObjects.autoteststore.HomePageObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest{

    @Test(description = "this is the first login test", groups = {"automationpracticedemo", "Logindemotest","smoke"})
    public void testLogin(){
        HomePageObject homePageObject = testApplication.get().getInstance(HomePageObject.class);
        homePageObject.clickOnLoginAndRegisterButton();
        EXTENTREPORTER.logInfo("clicked on login button.");

        homePageObject.enterUsername("shivam@gmail.com");
        EXTENTREPORTER.logInfo("entered username");

        Assert.assertTrue(false);

        homePageObject.enterPassword("123456789");
        EXTENTREPORTER.logInfo("entered password");

        homePageObject.clickOnLoginButton();
        EXTENTREPORTER.logInfo("Clicked on login button");
    }

}
