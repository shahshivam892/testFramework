package com.nova.reporter.reportengine.listeners;

import com.nova.core.TestApplication;
import com.nova.reporter.reportengine.Report;
import com.nova.reporter.reportengine.ReportEngine;
import com.nova.reporter.reportengine.core.Reporter;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TestListener implements ITestListener {
    private static Reporter reporter;

    @Override
    public void onStart(ITestContext context) {
        // Load reporter type from properties file
        String reportType = System.getProperty("report.type", "ALLURE_REPORT"); // or load from config.properties
//        reporter = ReportEngine.initializeReporter(Report.valueOf(reportType), "My_Report");
        reporter = ReportEngine.initializeReporter(Report.valueOf("ALLURE_REPORT"), "My_Report");
    }

    @Override
    public void onTestStart(ITestResult result) {
        reporter.createNewAndAssignTest(result.getMethod().getMethodName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        reporter.logPass("Test passed: " + result.getMethod().getMethodName());
    }

    @Override
    public void onTestFailure(ITestResult result) {
        reporter.logFail("Test failed: " + result.getThrowable().getMessage());

        // Generate unique screenshot filename
        String screenshotName = result.getMethod().getMethodName() + "_"
                + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".png";

        Object obj = result.getTestContext().getAttribute("testApplication");
        if (obj instanceof TestApplication) {
            ((TestApplication) obj)
                    .getTestContext()
                    .takeScreenShot(screenshotName+".png");
        }
       // Attach screenshot to report
        reporter.takeScreenshot(screenshotName+".png");
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        reporter.logSkip("Test skipped: " + result.getMethod().getMethodName());
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {

    }

    @Override
    public void onFinish(ITestContext context) {
        reporter.endOrCloseTest();
        reporter.closeReportEngine();
    }
}
