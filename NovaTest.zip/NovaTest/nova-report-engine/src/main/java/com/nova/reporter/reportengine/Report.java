/**
 * 
 */
package com.nova.reporter.reportengine;


public enum Report {

	/** The extent report. */
	EXTENT_REPORT,
	/** The allure report. */
	ALLURE_REPORT
}
