/**
 * 
 */
package com.nova.reporter.reportengine.core;


public interface Reporter {

	/**
	 * Log pass.
	 *
	 * @param message
	 *            the message
	 */
	public abstract void logPass(final String message);

	/**
	 * Log fail.
	 *
	 * @param message
	 *            the message
	 */
	public abstract void logFail(final String message);

	/**
	 * Log info.
	 *
	 * @param message
	 *            the message
	 */
	public abstract void logInfo(final String message);

	/**
	 * Log skip.
	 *
	 * @param message the message
	 */
	public abstract void logSkip(final String message);

	/**
	 * Initialize report engine.
	 *
	 * @param outputPath
	 *            the output path
	 */
	public abstract void initializeReportEngine(final String outputPath);

	/**
	 * Creates the new test.
	 *
	 * @param testName
	 *            the test name
	 */
	public abstract void createNewAndAssignTest(final String testName);

	/**
	 * End or close test.
	 */
	public abstract void endOrCloseTest();

	/**
	 * Close report engine.
	 */
	public abstract void closeReportEngine();

	/**
	 * Take screenshot.
	 *
	 * @param filePath the file path
	 */
	public abstract void takeScreenshot(final String filePath);

	/**
	 * Adds the file to report.
	 *
	 * @param filePath the file path
	 */
	public abstract void addFileToReport(final String filePath);
}
