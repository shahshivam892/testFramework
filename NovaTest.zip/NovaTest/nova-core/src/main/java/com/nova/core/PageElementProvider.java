/**
 * Page Element Provider Class
 */
package com.nova.core;

public class PageElementProvider {
	
	/** The context. */
	TestContext context;
	
	/**
	 * Instantiates a new page element provider.
	 *
	 * @param context the context
	 */
	public PageElementProvider(TestContext context)
	{
		this.context = context;
	}
}
