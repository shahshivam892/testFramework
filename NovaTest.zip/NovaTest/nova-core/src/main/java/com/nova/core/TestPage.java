/**
 * Core for Generic Pages
 */
package com.nova.core;


public abstract class TestPage {
	
	/** The text context. */
	protected TestContext textContext;
	
	
	/**
	 * Gets the test context.
	 *
	 * @return the test context
	 */
	public TestContext getTestContext() {
		return textContext;
	}


	/**
	 * Sets the text context.
	 *
	 * @param textContext the new text context
	 */
	public void setTextContext(TestContext textContext) {
		this.textContext = textContext;
	}


	/**
	 * Instantiates a new test page.
	 *
	 * @param context the context
	 */
	public TestPage(TestContext context)
	{
		this.textContext = context;
	}
	
	/**
	 * Take screen shot.
	 *
	 * @param title the title
	 */
	public void takeScreenShot(String title)
	{
		getTestContext().takeScreenShot(title);
	}
	
	/**
	 * Intialize element provider.
	 */
	public abstract void initializeElementProvider();
	
	
}
