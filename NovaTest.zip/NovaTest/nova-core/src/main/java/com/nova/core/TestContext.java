/**
 * Interface for common methods (actions)
 */
package com.nova.core;

public interface TestContext {
	
	/**
	 * Navigate to.
	 *
	 * @param url the url
	 */
	void navigateTo(String url);
	
	/**
	 * Enter text in.
	 *
	 * @param pageElement the page element
	 * @param text the text
	 */
	void enterTextIn(Object pageElement, String text);
    
    /**
     * Click button.
     *
     * @param pageElement the page element
     */
    void clickButton(Object pageElement);
    
    /**
     * Wait for.
     *
     * @param ms the ms
     */
    void waitFor(long ms);
    
    /**
     * Close.
     */
    void close();
    
    /**
     * Take screen shot.
     *
     * @param pageTitle the page title
     */
    void takeScreenShot(String pageTitle);
    
    /**
     * Gets the page title.
     *
     * @return the page title
     */
    String getPageTitle();
    
    /**
     * Gets the text.
     *
     * @param pageElement the page element
     * @return the text
     */
    String getText(Object pageElement);
    
    /**
     * Clear text box.
     *
     * @param pageElement the page element
     */
    void clearTextBox(Object pageElement);
    
    /**
     * Gets the attribute value.
     *
     * @param pageElement the page element
     * @param attributeName the attribute name
     * @return the attribute value
     */
    String getAttributeValue(Object pageElement, String attributeName);
    
    /**
     * Click.
     *
     * @param pageElement the page element
     */
    void click(Object pageElement);
    
    /**
     * Clear.
     *
     * @param pageElement the page element
     */
    void clear(Object pageElement);

    /**
     * Click.
     *
     * @param pageElement the page element
     * @return true, if is displayed
     */
    boolean isDisplayed(Object pageElement);

    /**
     * ScrollDown.
     */
    void scrollDown();
    
    /**
     * Hide key board.
     */
    void hideKeyBoard();
}
