/**
 * Test Application class would
 * initialize context and return page object
 */
package com.nova.core;

import java.lang.reflect.InvocationTargetException;

public class TestApplication {

    public TestContext testContext;

    public TestContext getTestContext() {
        return testContext;
    }

    public void setTestContext(TestContext testContext) {
        this.testContext = testContext;
    }

    @SuppressWarnings("unchecked")
    public <T extends TestPage> T getInstance(Class<?> TestPage) {
        T page = null;
        try {
            page = (T) TestPage.getConstructor(TestContext.class).newInstance(testContext);
            page.initializeElementProvider();

        } catch (InstantiationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SecurityException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return page;
    }
}