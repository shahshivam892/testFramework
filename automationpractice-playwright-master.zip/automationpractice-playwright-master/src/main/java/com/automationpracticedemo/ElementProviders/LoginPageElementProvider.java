package com.automationpracticedemo.ElementProviders;

import com.taf.core.PageElementProvider;
import com.taf.core.TestContext;
import com.taf.impl.playwright.PlaywrightElementProvider;
import com.taf.impl.playwright.PlaywrightTestContext;


/**
 * The Class LoginPageElementProvider.
 */
public class LoginPageElementProvider extends PageElementProvider {

    /** The playwright test context. */
    protected PlaywrightTestContext playwrightTestContext;

    /** The playwright element provider. */
    protected PlaywrightElementProvider playwrightElementProvider;

    /**
     * Instantiates a new base element provider.
     *
     * @param context
     *            the context
     */
    public LoginPageElementProvider(final TestContext context) {
        super(context);
        playwrightTestContext = (PlaywrightTestContext) context;
        playwrightElementProvider = new PlaywrightElementProvider(playwrightTestContext);
    }

					
		public Object getUsername(){
		        return playwrightElementProvider.getElementByID("username");
	    	}
	    	
    			
		public Object getPassword(){
		        return playwrightElementProvider.getElementByID("password");
	    	}
	    	
    			
		public Object getLogin(){
		        return playwrightElementProvider.getElementByName("login");
	    	}
	    	
    			
		public Object getVerigyLoginErrorMessage(){
		        return playwrightElementProvider.getElementByXpath("//strong[contains(text(),'ERROR')]");
	    	}
	    	
    	}