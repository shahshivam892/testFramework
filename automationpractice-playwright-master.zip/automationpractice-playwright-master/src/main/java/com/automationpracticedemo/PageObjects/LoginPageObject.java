package com.automationpracticedemo.PageObjects;

import com.taf.core.TestContext;
import com.taf.core.TestPage;
import com.taf.impl.playwright.PlaywrightTestContext;
import com.automationpracticedemo.ElementProviders.LoginPageElementProvider;

/**
 * The Class LoginPageObject.
 */
public class LoginPageObject extends TestPage {

    /** The playwright test context. */
    private final PlaywrightTestContext playwrightTestContext;

    /** The sign up page element provider. */
    private LoginPageElementProvider loginPageElementProvider;

    /**
     * Instantiates a new sign up page.
     *
     * @param context
     *            the context
     */
    public LoginPageObject(final TestContext context){
        super(context);
        playwrightTestContext = (PlaywrightTestContext) context;
    }
    
    /*
     * (non-Javadoc)
     *
     * @see com.taf.core.TestPage#intializeElementProvider()
     */
    @Override
    public void initializeElementProvider(){
        loginPageElementProvider = new LoginPageElementProvider(playwrightTestContext);
    }
    
    
          
    public void clickUsername(){
		     playwrightTestContext.clickButton(loginPageElementProvider.getUsername());
		}
		
         
    public void enterUsername(final String text){
		     playwrightTestContext.enterTextIn(loginPageElementProvider.getUsername(),text);
		}
		
         
    public void clickPassword(){
		     playwrightTestContext.clickButton(loginPageElementProvider.getPassword());
		}
		
         
    public void enterPassword(final String text){
		     playwrightTestContext.enterTextIn(loginPageElementProvider.getPassword(),text);
		}
		
         
    public void clickLogin(){
		     playwrightTestContext.clickButton(loginPageElementProvider.getLogin());
		}
		
         
    public String verifyTextVerigyLoginErrorMessage(){
		    return playwrightTestContext.getText(loginPageElementProvider.getVerigyLoginErrorMessage());
		}
		
        
        
    public void LoginFunc(String username,String password){
		    		    clickUsername();
		    		    enterUsername(username);
		    		    clickPassword();
		    		    enterPassword(password);
		    		    clickLogin();
		    		}
		
      }
    