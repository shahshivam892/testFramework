package com.automationpracticedemo.TestCases;

import org.testng.annotations.Test;
import com.automationpracticedemo.PageObjects.*;
import org.testng.asserts.SoftAssert;
import org.testng.Assert;

public class AutomationpracticedemoTestCaseTestNgTest extends BaseTestNgTest {

	@Test(description = "This is Logindemotest", groups = { "automationpracticedemo", "Logindemotest","smoke" })
	public void testVerifyLoginError() {

		SoftAssert softassert = new SoftAssert();

		LoginPageObject loginpageobject = testApplication.get().getInstance(LoginPageObject.class);

		loginpageobject.LoginFunc("demo", "demo");
		EXTENTREPORTER.logInfo("Enter Username and Password");

		softassert.assertEquals(loginpageobject.verifyTextVerigyLoginErrorMessage(),"ERROR");
		EXTENTREPORTER.logInfo("Username or Password is incorrect");

		softassert.assertAll();

	}
}