package com.taf.impl.playwright;

import com.taf.core.TestContext;
import com.taf.core.ToolElementProvider;

/**
 * The Class PlaywrightElementProvider.
 */
public class PlaywrightElementProvider extends ToolElementProvider {

	/** The playwright context. */
	PlaywrightTestContext _playwrightContext;

	/**
	 * Instantiates a new playwright element provider.
	 *
	 * @param context the context
	 */
	public PlaywrightElementProvider(TestContext context) {
		super(context);
		_playwrightContext = (PlaywrightTestContext) context;
	}

	/**
	 * Gets the element by ID.
	 *
	 * @param id the id
	 * @return the element by ID
	 */
	@Override
	public Object getElementByID(String id) {
		return _playwrightContext.getPage().waitForSelector(new StringBuilder("id=").append(id).toString());
	}

	/**
	 * Gets the element by name.
	 *
	 * @param name the name
	 * @return the element by name
	 */
	@Override
	public Object getElementByName(String name) {
		return _playwrightContext.getPage().waitForSelector(new StringBuilder("xpath=//input[@name=\"").append(name).append("\"]").toString());
	}

	/**
	 * Gets the element by xpath.
	 *
	 * @param xpath the xpath
	 * @return the element by xpath
	 */
	public Object getElementByXpath(String xpath) {
		return _playwrightContext.getPage().waitForSelector(new StringBuilder("xpath=").append(xpath).toString());
	}

	/**
	 * Gets the element by link text.
	 *
	 * @param linkText the link text
	 * @return the element by link text
	 */
	public Object getElementByLinkText(String linkText) {
		return _playwrightContext.getPage().waitForSelector(
				new StringBuilder("xpath=//a[contains(text(),'").append(linkText).append("')]").toString());
	}

	/**
	 * Gets the element by partial link text.
	 *
	 * @param linkText the link text
	 * @return the element by partial link text
	 */
	public Object getElementByPartialLinkText(String linkText) {
		return _playwrightContext.getPage().waitForSelector(
				new StringBuilder("xpath=//a[contains(text(),'").append(linkText).append("')]").toString());
	}

	/**
	 * Gets the element by CSS selector.
	 *
	 * @param css the css
	 * @return the element by CSS selector
	 */
	public Object getElementByCSSSelector(String css) {
		return _playwrightContext.getPage().waitForSelector(new StringBuilder("css=").append(css).toString());
	}

	/**
	 * Gets the element by tag name.
	 *
	 * @param tagName the tag name
	 * @return the element by tag name
	 */
	public Object getElementByTagName(String tagName) {
		return _playwrightContext.getPage().waitForSelector(new StringBuilder("tagname=").append(tagName).toString());
	}

	/**
	 * Gets the element from parent.
	 *
	 * @param elementBy the element by
	 * @param childBy   the child by
	 * @return the element from parent
	 */
	public Object getElementFromParent(String elementBy, String childBy) {
		return _playwrightContext.getPage().waitForSelector(elementBy).querySelector("xpath=//parent::div")
				.querySelector(childBy);
	}

	/**
	 * Gets the text element by label.
	 *
	 * @param label the label
	 * @return the text element by label
	 */
	public Object getTextElementByLabel(String label) {
		return _playwrightContext.getPage().waitForSelector(new StringBuilder("xpath=")
				.append("//label[contains(text(),\"").append(label).append("\")]//parent::div//input").toString());

	}

	/**
	 * Gets the elements by xpath.
	 *
	 * @param xpath the xpath
	 * @return the elements by xpath
	 */
	public Object getElementsByXpath(String xpath) {
		_playwrightContext.getPage().waitForSelector(new StringBuilder("xpath=").append(xpath).toString());
		return _playwrightContext.getPage().querySelectorAll(new StringBuilder("xpath=").append(xpath).toString());
	}
}
